import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { User } from "@supabase/supabase-js";

export type AppRole = "admin" | "manager" | "head";

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<AppRole | null>(null);
  const [loading, setLoading] = useState(true);
  const [roleLoading, setRoleLoading] = useState(true);

  useEffect(() => {
    let mounted = true;

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, session) => {
      if (!mounted) return;
      setUser(session?.user ?? null);
      if (session?.user) {
        setRoleLoading(true);
        setTimeout(() => fetchRole(session.user.id), 0);
      } else {
        setRole(null);
        setRoleLoading(false);
      }
    });

    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!mounted) return;
      setUser(session?.user ?? null);
      if (session?.user) {
        await fetchRole(session.user.id);
      } else {
        setRoleLoading(false);
      }
      if (mounted) setLoading(false);
    })();

    return () => { mounted = false; subscription.unsubscribe(); };
  }, []);

  async function fetchRole(userId: string) {
    const { data, error } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .order("role", { ascending: true })
      .limit(1)
      .maybeSingle();
    if (error) console.error("fetchRole error", error);
    setRole((data?.role as AppRole) ?? null);
    setRoleLoading(false);
  }

  return {
    user,
    role,
    loading: loading || (!!user && roleLoading),
    isAdmin: role === "admin",
    isHead: role === "head",
    isPending: !!user && !role && !roleLoading,
  };
}
