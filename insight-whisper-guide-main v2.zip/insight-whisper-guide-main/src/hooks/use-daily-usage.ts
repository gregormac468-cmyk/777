import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

export type DailyUsage = { used: number; daily_limit: number | null };

export function useDailyUsage(userId: string | undefined) {
  const [usage, setUsage] = useState<DailyUsage | null>(null);
  const [loading, setLoading] = useState(false);

  const reload = useCallback(async () => {
    if (!userId) return;
    setLoading(true);
    const { data } = await (supabase as any).rpc("get_user_daily_usage", { _user_id: userId });
    const row = Array.isArray(data) ? data[0] : null;
    setUsage(row ? { used: row.used ?? 0, daily_limit: row.daily_limit ?? null } : { used: 0, daily_limit: null });
    setLoading(false);
  }, [userId]);

  useEffect(() => { reload(); }, [reload]);

  const exceeded = !!usage && usage.daily_limit !== null && usage.used >= usage.daily_limit;
  const remaining = usage && usage.daily_limit !== null ? Math.max(0, usage.daily_limit - usage.used) : null;

  return { usage, loading, reload, exceeded, remaining };
}
