"use client";

import { useCallback, useRef, useState, type CSSProperties } from "react";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "@/hooks/use-theme";

export interface CurtainThemeToggleProps {
  buttonSize?: number;
  duration?: number;
}

const EASING = "cubic-bezier(0.76, 0, 0.24, 1)";

// Curtain colors per resolved theme — should match page background for seamless transition.
const CURTAIN_BG: Record<"light" | "dark", string> = {
  light: "oklch(0.985 0.005 250)",
  dark: "oklch(0.17 0.025 260)",
};

type Phase = "idle" | "falling" | "rising";

export function CurtainThemeToggle({
  buttonSize = 36,
  duration = 550,
}: CurtainThemeToggleProps) {
  const { resolvedTheme, setTheme } = useTheme();
  const [phase, setPhase] = useState<Phase>("idle");
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);
  const curtainColorRef = useRef<string>("");

  const toggle = useCallback(() => {
    if (phase !== "idle") return;
    const next: "light" | "dark" = resolvedTheme === "light" ? "dark" : "light";
    curtainColorRef.current = CURTAIN_BG[next];
    setPhase("falling");

    window.setTimeout(() => {
      setTheme(next);
      setPhase("rising");
      window.setTimeout(() => setPhase("idle"), duration + 60);
    }, duration);
  }, [phase, resolvedTheme, setTheme, duration]);

  const btnScale = pressed ? 0.96 : hovered ? 1.1 : 1;

  const btnStyle: CSSProperties = {
    width: buttonSize,
    height: buttonSize,
    borderRadius: "50%",
    border: "none",
    cursor: "pointer",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    background: "var(--card)",
    color: "var(--foreground)",
    boxShadow: "0 0 0 1.5px var(--border)",
    transform: `scale(${btnScale})`,
    transition:
      "background 0.3s ease, color 0.3s ease, transform 0.15s ease, box-shadow 0.3s ease",
    outline: "none",
  };

  const curtainStyle: CSSProperties = {
    position: "fixed",
    inset: 0,
    background: curtainColorRef.current,
    transformOrigin: "top",
    transform: phase === "falling" ? "scaleY(1)" : "scaleY(0)",
    transition: phase !== "idle" ? `transform ${duration}ms ${EASING}` : "none",
    zIndex: 9997,
    pointerEvents: "none",
  };

  return (
    <>
      <div style={curtainStyle} aria-hidden />
      <button
        type="button"
        onClick={toggle}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => {
          setHovered(false);
          setPressed(false);
        }}
        onMouseDown={() => setPressed(true)}
        onMouseUp={() => setPressed(false)}
        style={btnStyle}
        aria-label={
          resolvedTheme === "light" ? "Switch to dark mode" : "Switch to light mode"
        }
        aria-pressed={resolvedTheme === "dark"}
      >
        {resolvedTheme === "light" ? (
          <Moon className="size-4" />
        ) : (
          <Sun className="size-4" />
        )}
      </button>
    </>
  );
}
