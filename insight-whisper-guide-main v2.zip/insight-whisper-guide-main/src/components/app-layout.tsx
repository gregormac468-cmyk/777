import { Link, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Headphones, Upload, FileText, Users, LogOut, LayoutDashboard, Briefcase, Sparkles, Menu, X, KeyRound, Activity, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { useState, useEffect } from "react";
import { CurtainThemeToggle } from "@/components/ui/curtain-theme-toggle";

export function AppLayout() {
  const { user, isAdmin, isHead, isPending, loading } = useAuth();
  const navigate = useNavigate();
  const { location } = useRouterState();
  const [open, setOpen] = useState(false);

  // Close drawer on route change
  useEffect(() => { setOpen(false); }, [location.pathname]);

  if (loading) {
    return <div className="min-h-screen grid place-items-center text-muted-foreground">Загрузка…</div>;
  }

  if (!user) {
    if (typeof window !== "undefined" && location.pathname !== "/login") {
      navigate({ to: "/login" });
    }
    return null;
  }

  if (isPending) {
    return (
      <div className="min-h-screen grid place-items-center bg-background p-4">
        <div className="max-w-md w-full bg-card border rounded-xl p-8 text-center space-y-5 shadow-sm">
          <div className="mx-auto size-14 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400 grid place-items-center">
            <Clock className="size-7" />
          </div>
          <div className="space-y-2">
            <h1 className="text-xl font-semibold">Ожидание подтверждения</h1>
            <p className="text-sm text-muted-foreground">
              Ваш аккаунт зарегистрирован, но ещё не активирован. Доступ к сервису появится после того, как администратор подтвердит вашу учётную запись и назначит роль.
            </p>
            <p className="text-xs text-muted-foreground pt-2">
              Вы вошли как <span className="font-medium text-foreground">{user.email}</span>
            </p>
          </div>
          <Button variant="outline" className="w-full" onClick={async () => {
            await supabase.auth.signOut();
            navigate({ to: "/login" });
          }}>
            <LogOut className="size-4 mr-2" /> Выйти
          </Button>
        </div>
      </div>
    );
  }

  const nav = [
    { to: "/", label: "Дашборд", icon: LayoutDashboard },
    { to: "/upload", label: "Загрузить", icon: Upload },
    { to: "/ai-analysis", label: "Анализ ИИ", icon: Sparkles },
    { to: "/sales-team", label: "Отдел продаж", icon: Briefcase },
    { to: "/instructions", label: "Инструкции", icon: FileText, adminOrHead: true },
    { to: "/ai-providers", label: "AI-провайдеры", icon: KeyRound, adminOnly: true },
    { to: "/users", label: "Пользователи", icon: Users, adminOnly: true },
    { to: "/activity", label: "Журнал действий", icon: Activity, adminOnly: true },
  ] as Array<{ to: string; label: string; icon: typeof LayoutDashboard; adminOnly?: boolean; adminOrHead?: boolean }>;

  const sidebar = (
    <>
      <div className="p-5 border-b flex items-center gap-2">
        <div className="size-9 rounded-lg bg-primary grid place-items-center">
          <Headphones className="size-5 text-primary-foreground" />
        </div>
        <div className="flex-1">
          <div className="font-semibold leading-tight">Контроль</div>
          <div className="text-xs text-muted-foreground">звонков</div>
        </div>
        <Button variant="ghost" size="icon" onClick={() => setOpen(false)}>
          <X className="size-5" />
        </Button>
      </div>
      <nav className="flex-1 p-3 space-y-1 overflow-auto">
        {nav.filter(n => {
          if (n.adminOnly) return isAdmin;
          if (n.adminOrHead) return isAdmin || isHead;
          return true;
        }).map(n => {
          const active = location.pathname === n.to || (n.to !== "/" && location.pathname.startsWith(n.to));
          return (
            <Link
              key={n.to}
              to={n.to}
              className={cn(
                "flex items-center gap-3 px-3 py-2 rounded-md text-sm transition",
                active ? "bg-primary text-primary-foreground" : "hover:bg-accent text-foreground"
              )}
            >
              <n.icon className="size-4" />
              {n.label}
            </Link>
          );
        })}
      </nav>
      <div className="p-3 border-t">
        <div className="text-xs text-muted-foreground px-2 pb-2 truncate">{user.email}</div>
        <div className="text-xs px-2 pb-2">
          <span className={cn("inline-block px-2 py-0.5 rounded-full",
            isAdmin ? "bg-primary/10 text-primary" : isHead ? "bg-amber-500/10 text-amber-700 dark:text-amber-400" : "bg-secondary text-secondary-foreground")}>
            {isAdmin ? "Админ" : isHead ? "Руководитель" : "Менеджер"}
          </span>
        </div>
        <Button variant="ghost" size="sm" className="w-full justify-start" onClick={async () => {
          await supabase.auth.signOut();
          navigate({ to: "/login" });
        }}>
          <LogOut className="size-4 mr-2" /> Выйти
        </Button>
      </div>
    </>
  );

  return (
    <div className="min-h-screen flex bg-background">
      {/* Overlay: closes drawer on outside click (all screen sizes) */}
      {open && (
        <div
          className="fixed inset-0 z-40 bg-black/50"
          onClick={() => setOpen(false)}
        />
      )}

      {/* Sidebar: slides in on toggle, auto-closes when cursor leaves */}
      <aside
        onMouseLeave={() => setOpen(false)}
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 border-r bg-card flex flex-col transition-transform duration-200",
          open ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {sidebar}
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-14 border-b bg-card flex items-center px-3 gap-2 sticky top-0 z-30">
          <Button variant="ghost" size="icon" onClick={() => setOpen(v => !v)} aria-label="Меню">
            <Menu className="size-5" />
          </Button>
          <div className="flex items-center gap-2">
            <div className="size-7 rounded-md bg-primary grid place-items-center">
              <Headphones className="size-4 text-primary-foreground" />
            </div>
            <span className="font-semibold text-sm">Контроль звонков</span>
          </div>
          <div className="ml-auto">
            <CurtainThemeToggle />
          </div>
        </header>
        <main className="flex-1 overflow-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
