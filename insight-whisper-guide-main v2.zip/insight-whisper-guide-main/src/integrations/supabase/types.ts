export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      activity_logs: {
        Row: {
          action: string
          created_at: string
          entity_id: string | null
          entity_type: string | null
          id: string
          metadata: Json | null
          user_id: string
        }
        Insert: {
          action: string
          created_at?: string
          entity_id?: string | null
          entity_type?: string | null
          id?: string
          metadata?: Json | null
          user_id: string
        }
        Update: {
          action?: string
          created_at?: string
          entity_id?: string | null
          entity_type?: string | null
          id?: string
          metadata?: Json | null
          user_id?: string
        }
        Relationships: []
      }
      ai_settings: {
        Row: {
          analysis_model: string
          analysis_provider: string
          anthropic_key_mask: string | null
          anthropic_secret_id: string | null
          deepseek_key_mask: string | null
          deepseek_secret_id: string | null
          google_key_mask: string | null
          google_secret_id: string | null
          id: string
          openai_key_mask: string | null
          openai_secret_id: string | null
          qwen_key_mask: string | null
          qwen_secret_id: string | null
          singleton: boolean
          token_stats_reset_at: string | null
          transcription_model: string
          transcription_provider: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          analysis_model?: string
          analysis_provider?: string
          anthropic_key_mask?: string | null
          anthropic_secret_id?: string | null
          deepseek_key_mask?: string | null
          deepseek_secret_id?: string | null
          google_key_mask?: string | null
          google_secret_id?: string | null
          id?: string
          openai_key_mask?: string | null
          openai_secret_id?: string | null
          qwen_key_mask?: string | null
          qwen_secret_id?: string | null
          singleton?: boolean
          token_stats_reset_at?: string | null
          transcription_model?: string
          transcription_provider?: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          analysis_model?: string
          analysis_provider?: string
          anthropic_key_mask?: string | null
          anthropic_secret_id?: string | null
          deepseek_key_mask?: string | null
          deepseek_secret_id?: string | null
          google_key_mask?: string | null
          google_secret_id?: string | null
          id?: string
          openai_key_mask?: string | null
          openai_secret_id?: string | null
          qwen_key_mask?: string | null
          qwen_secret_id?: string | null
          singleton?: boolean
          token_stats_reset_at?: string | null
          transcription_model?: string
          transcription_provider?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: []
      }
      calls: {
        Row: {
          analysis: Json | null
          created_at: string
          duration_seconds: number | null
          error_message: string | null
          file_name: string
          id: string
          instruction_id: string | null
          manager_name: string | null
          status: Database["public"]["Enums"]["call_status"]
          storage_path: string
          transcript: string | null
          updated_at: string
          uploaded_by: string
        }
        Insert: {
          analysis?: Json | null
          created_at?: string
          duration_seconds?: number | null
          error_message?: string | null
          file_name: string
          id?: string
          instruction_id?: string | null
          manager_name?: string | null
          status?: Database["public"]["Enums"]["call_status"]
          storage_path: string
          transcript?: string | null
          updated_at?: string
          uploaded_by: string
        }
        Update: {
          analysis?: Json | null
          created_at?: string
          duration_seconds?: number | null
          error_message?: string | null
          file_name?: string
          id?: string
          instruction_id?: string | null
          manager_name?: string | null
          status?: Database["public"]["Enums"]["call_status"]
          storage_path?: string
          transcript?: string | null
          updated_at?: string
          uploaded_by?: string
        }
        Relationships: [
          {
            foreignKeyName: "calls_instruction_id_fkey"
            columns: ["instruction_id"]
            isOneToOne: false
            referencedRelation: "instructions"
            referencedColumns: ["id"]
          },
        ]
      }
      instructions: {
        Row: {
          content: string
          created_at: string
          created_by: string | null
          id: string
          is_active: boolean
          name: string
          updated_at: string
        }
        Insert: {
          content: string
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          content?: string
          created_at?: string
          created_by?: string | null
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      managers: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          name: string
          position: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          name: string
          position?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          name?: string
          position?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          email: string | null
          full_name: string | null
          id: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
        }
        Update: {
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
        }
        Relationships: []
      }
      user_limits: {
        Row: {
          daily_limit: number | null
          updated_at: string
          updated_by: string | null
          user_id: string
        }
        Insert: {
          daily_limit?: number | null
          updated_at?: string
          updated_by?: string | null
          user_id: string
        }
        Update: {
          daily_limit?: number | null
          updated_at?: string
          updated_by?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_user_daily_usage: {
        Args: { _user_id: string }
        Returns: {
          daily_limit: number
          used: number
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      reset_call_for_reprocess: {
        Args: { _call_id: string }
        Returns: undefined
      }
      reset_calls_for_reprocess: {
        Args: { _call_ids: string[] }
        Returns: undefined
      }
      set_ai_provider_key: {
        Args: { _key: string; _provider: string }
        Returns: undefined
      }
    }
    Enums: {
      app_role: "admin" | "manager" | "head"
      call_status: "pending" | "transcribing" | "analyzing" | "done" | "error"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "manager", "head"],
      call_status: ["pending", "transcribing", "analyzing", "done", "error"],
    },
  },
} as const
