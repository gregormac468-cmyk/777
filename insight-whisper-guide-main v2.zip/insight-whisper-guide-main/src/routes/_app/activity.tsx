import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const Route = createFileRoute("/_app/activity")({
  component: ActivityPage,
});

type LogRow = {
  id: string;
  user_id: string;
  action: string;
  entity_type: string | null;
  entity_id: string | null;
  metadata: Record<string, unknown> | null;
  created_at: string;
};

const actionLabels: Record<string, string> = {
  "instruction.create": "Создал инструкцию",
  "instruction.activate": "Активировал инструкцию",
  "instruction.delete": "Удалил инструкцию",
  "manager.create": "Добавил сотрудника",
  "manager.delete": "Удалил сотрудника",
  "call.upload": "Загрузил звонки",
  "user.create": "Создал пользователя",
  "user.role_change": "Изменил роль пользователя",
  "user.limit_change": "Изменил суточный лимит",
};

function ActivityPage() {
  const { isAdmin } = useAuth();
  const [rows, setRows] = useState<LogRow[]>([]);
  const [profiles, setProfiles] = useState<Record<string, { email: string | null; full_name: string | null }>>({});
  const [filterUser, setFilterUser] = useState<string>("all");
  const [filterAction, setFilterAction] = useState<string>("all");
  const [loading, setLoading] = useState(false);

  async function load() {
    setLoading(true);
    const [logsRes, profilesRes] = await Promise.all([
      (supabase as any).from("activity_logs").select("*").order("created_at", { ascending: false }).limit(500),
      supabase.from("profiles").select("id, email, full_name"),
    ]);
    setLoading(false);
    setRows((logsRes.data as LogRow[]) ?? []);
    const map: Record<string, { email: string | null; full_name: string | null }> = {};
    (profilesRes.data ?? []).forEach((p: any) => { map[p.id] = { email: p.email, full_name: p.full_name }; });
    setProfiles(map);
  }

  useEffect(() => { if (isAdmin) load(); }, [isAdmin]);

  if (!isAdmin) return <div className="p-8">Доступ только для администраторов.</div>;

  const userOptions = Array.from(new Set(rows.map(r => r.user_id)));
  const actionOptions = Array.from(new Set(rows.map(r => r.action)));

  const filtered = rows.filter(r =>
    (filterUser === "all" || r.user_id === filterUser) &&
    (filterAction === "all" || r.action === filterAction)
  );

  function userName(id: string) {
    const p = profiles[id];
    return p?.full_name || p?.email || id.slice(0, 8);
  }

  function describe(r: LogRow): string {
    const label = actionLabels[r.action] ?? r.action;
    const m = r.metadata as any;
    if (r.action === "call.upload" && m?.count) return `${label}: ${m.count} шт.${m.manager ? ` (${m.manager})` : ""}`;
    if (r.action === "instruction.create" && m?.name) return `${label}: «${m.name}»`;
    if (r.action === "instruction.activate" && m?.name) return `${label}: «${m.name}»`;
    if (r.action === "instruction.delete" && m?.name) return `${label}: «${m.name}»`;
    if (r.action === "manager.create" && m?.name) return `${label}: ${m.name}${m.position ? ` (${m.position})` : ""}`;
    if (r.action === "manager.delete" && m?.name) return `${label}: ${m.name}`;
    if (r.action === "user.create" && m?.email) return `${label}: ${m.email}${m.role ? ` (${m.role})` : ""}`;
    if (r.action === "user.role_change" && m?.email) return `${label}: ${m.email} → ${m.role}`;
    if (r.action === "user.limit_change" && m?.email) return `${label}: ${m.email} → ${m.daily_limit ?? "без лимита"}`;
    return label;
  }

  return (
    <div className="p-4 sm:p-6 md:p-8 max-w-5xl mx-auto">
      <header className="mb-6 flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold">Журнал действий</h1>
          <p className="text-sm text-muted-foreground mt-1">Действия пользователей в системе</p>
        </div>
        <Button variant="outline" size="sm" onClick={load} disabled={loading}>{loading ? "..." : "Обновить"}</Button>
      </header>

      <Card className="mb-4">
        <CardContent className="pt-4 flex flex-wrap gap-3">
          <div className="space-y-1">
            <label className="text-xs text-muted-foreground">Пользователь</label>
            <Select value={filterUser} onValueChange={setFilterUser}>
              <SelectTrigger className="w-56"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все</SelectItem>
                {userOptions.map(uid => (
                  <SelectItem key={uid} value={uid}>{userName(uid)}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <label className="text-xs text-muted-foreground">Действие</label>
            <Select value={filterAction} onValueChange={setFilterAction}>
              <SelectTrigger className="w-64"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Все</SelectItem>
                {actionOptions.map(a => (
                  <SelectItem key={a} value={a}>{actionLabels[a] ?? a}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Записи ({filtered.length})</CardTitle></CardHeader>
        <CardContent className="space-y-2">
          {filtered.length === 0 && <div className="text-sm text-muted-foreground py-6 text-center">Нет записей</div>}
          {filtered.map(r => (
            <div key={r.id} className="flex items-start gap-3 p-3 rounded-md border">
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-medium">{userName(r.user_id)}</span>
                  <Badge variant="secondary" className="text-xs">{r.action}</Badge>
                </div>
                <div className="text-sm mt-1">{describe(r)}</div>
                <div className="text-xs text-muted-foreground mt-1">
                  {new Date(r.created_at).toLocaleString("ru-RU")}
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
