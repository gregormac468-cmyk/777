import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, RefreshCw, FileAudio, ChevronDown, ChevronRight } from "lucide-react";
import { toast } from "sonner";
import { normalizeScore } from "@/lib/utils";

export const Route = createFileRoute("/_app/calls/$callId")({
  component: CallDetail,
});

type Criterion = { name: string; score: number; comment: string };
type Analysis = {
  call_type?: string;
  overall_score?: number;
  summary?: string;
  criteria?: Criterion[];
  strengths?: string[];
  weaknesses?: string[];
  recommendations?: string[];
};
type Call = {
  id: string;
  file_name: string;
  manager_name: string | null;
  status: string;
  error_message: string | null;
  transcript: string | null;
  analysis: Analysis | null;
  created_at: string;
  storage_path: string;
};

function CallDetail() {
  const { callId } = Route.useParams();
  const [call, setCall] = useState<Call | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [transcriptOpen, setTranscriptOpen] = useState(false);
  const [isReprocessing, setIsReprocessing] = useState(false);

  async function load() {
    const { data } = await supabase.from("calls").select("*").eq("id", callId).single();
    setCall(data as Call);
    if (data?.storage_path) {
      const { data: signed } = await supabase.storage.from("call-audio").createSignedUrl(data.storage_path, 3600);
      setAudioUrl(signed?.signedUrl ?? null);
    }
  }

  useEffect(() => {
    load();
    const channel = supabase
      .channel(`call-${callId}`)
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "calls", filter: `id=eq.${callId}` }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [callId]);

  async function reprocess() {
    if (isReprocessing) return;
    setIsReprocessing(true);
    setCall((prev) => prev ? { ...prev, status: "pending", error_message: null, analysis: null } : prev);

    const { error: resetError } = await supabase.rpc("reset_call_for_reprocess", { _call_id: callId });

    if (resetError) {
      toast.error(`Не удалось поставить звонок в очередь: ${resetError.message}`);
      await load();
      setIsReprocessing(false);
      return;
    }

    await load();
    const { error } = await supabase.functions.invoke("process-call", { body: { callId } });
    if (error) {
      await supabase
        .from("calls")
        .update({ status: "error", error_message: `Не удалось запустить обработку: ${error.message}` })
        .eq("id", callId);
      toast.error(`Не удалось запустить обработку: ${error.message}`);
    } else {
      toast.success("Звонок снова поставлен в обработку");
    }
    await load();
    setIsReprocessing(false);
  }

  if (!call) return <div className="p-8">Загрузка…</div>;
  const a = call.analysis;
  const score = normalizeScore(a?.overall_score);

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-6">
      <Link to="/ai-analysis" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-4 mr-1" /> Назад
      </Link>

      <header className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-3 mb-2">
            <FileAudio className="size-5 text-muted-foreground" />
            <h1 className="text-2xl font-bold truncate">{call.file_name}</h1>
          </div>
          <div className="text-sm text-muted-foreground">
            {call.manager_name ?? "—"} · {new Date(call.created_at).toLocaleString("ru-RU")}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge>{call.status}</Badge>
          {(call.status === "error" || call.status === "done") && (
            <Button size="sm" variant="outline" onClick={reprocess} disabled={isReprocessing}>
              <RefreshCw className={`size-4 mr-1 ${isReprocessing ? "animate-spin" : ""}`} />
              {isReprocessing ? "Запуск…" : "Повторить"}
            </Button>
          )}
        </div>
      </header>

      {audioUrl && <audio controls src={audioUrl} className="w-full" />}

      {call.transcript ? (
        <Card>
          <button
            type="button"
            onClick={() => setTranscriptOpen((v) => !v)}
            className="w-full flex items-center justify-between p-6 text-left hover:bg-muted/40 transition-colors"
          >
            <CardTitle className="text-lg">Транскрипт разговора</CardTitle>
            {transcriptOpen ? <ChevronDown className="size-5 text-muted-foreground" /> : <ChevronRight className="size-5 text-muted-foreground" />}
          </button>
          {transcriptOpen && (
            <CardContent>
              <p className="text-sm whitespace-pre-wrap leading-relaxed max-h-[420px] overflow-auto">{call.transcript}</p>
            </CardContent>
          )}
        </Card>
      ) : call.status === "done" ? (
        <Card><CardContent className="py-4 text-sm text-muted-foreground">Транскрипт отсутствует.</CardContent></Card>
      ) : null}

      {call.status === "error" && (
        <Card className="border-destructive">
          <CardContent className="pt-6 text-sm text-destructive">{call.error_message}</CardContent>
        </Card>
      )}

      {(call.status === "transcribing" || call.status === "analyzing" || call.status === "pending") && (
        <Card><CardContent className="py-8 text-center text-muted-foreground">
          {call.status === "pending" && "В очереди…"}
          {call.status === "transcribing" && "Транскрибируем разговор через Gemini…"}
          {call.status === "analyzing" && "AI анализирует разговор…"}
        </CardContent></Card>
      )}

      {a && (
        <>
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Оценка</CardTitle>
                {score != null && (
                  <div className="text-right">
                    <div className="text-4xl font-bold text-primary">{score.toFixed(1)}<span className="text-lg text-muted-foreground">/10</span></div>
                  </div>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {a.call_type && <div><span className="text-sm text-muted-foreground">Тип звонка: </span><span className="font-medium">{a.call_type}</span></div>}
              {a.summary && <p className="text-sm leading-relaxed">{a.summary}</p>}
            </CardContent>
          </Card>

          {a.criteria && a.criteria.length > 0 && (
            <Card>
              <CardHeader><CardTitle>Критерии</CardTitle></CardHeader>
              <CardContent className="space-y-3">
                {a.criteria.map((c, i) => {
                  const cs = normalizeScore(c.score) ?? 0;
                  return (
                  <div key={i} className="border-l-4 pl-4 py-1" style={{ borderColor: cs >= 7 ? "oklch(0.7 0.17 145)" : cs >= 4 ? "oklch(0.75 0.15 80)" : "oklch(0.65 0.2 25)" }}>
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{c.name}</span>
                      <span className="text-sm font-bold">{cs.toFixed(1)}/10</span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">{c.comment}</p>
                  </div>
                  );
                })}
              </CardContent>
            </Card>
          )}

          <div className="grid md:grid-cols-2 gap-4">
            {a.strengths && a.strengths.length > 0 && (
              <Card>
                <CardHeader><CardTitle className="text-base">Сильные стороны</CardTitle></CardHeader>
                <CardContent><ul className="text-sm space-y-1.5 list-disc pl-5">{a.strengths.map((s, i) => <li key={i}>{s}</li>)}</ul></CardContent>
              </Card>
            )}
            {a.weaknesses && a.weaknesses.length > 0 && (
              <Card>
                <CardHeader><CardTitle className="text-base">Слабые стороны</CardTitle></CardHeader>
                <CardContent><ul className="text-sm space-y-1.5 list-disc pl-5">{a.weaknesses.map((s, i) => <li key={i}>{s}</li>)}</ul></CardContent>
              </Card>
            )}
          </div>

          {a.recommendations && a.recommendations.length > 0 && (
            <Card>
              <CardHeader><CardTitle className="text-base">Рекомендации</CardTitle></CardHeader>
              <CardContent><ul className="text-sm space-y-1.5 list-disc pl-5">{a.recommendations.map((s, i) => <li key={i}>{s}</li>)}</ul></CardContent>
            </Card>
          )}
        </>
      )}

    </div>
  );
}
