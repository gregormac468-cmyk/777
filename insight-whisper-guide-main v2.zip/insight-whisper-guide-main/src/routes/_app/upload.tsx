import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, useRef, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload as UploadIcon, FileAudio, X, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/hooks/use-auth";
import { useDailyUsage } from "@/hooks/use-daily-usage";
import { logActivity } from "@/lib/activity-log";

type Manager = { id: string; name: string; position: string | null };

export const Route = createFileRoute("/_app/upload")({
  component: UploadPage,
});

function UploadPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { usage, reload: reloadUsage, exceeded, remaining } = useDailyUsage(user?.id);
  const [files, setFiles] = useState<File[]>([]);
  const [managerName, setManagerName] = useState<string>("");
  const [managers, setManagers] = useState<Manager[]>([]);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState<{ current: number; total: number; waiting: number } | null>(null);
  const [delaySeconds, setDelaySeconds] = useState<number>(15);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    supabase.from("managers").select("id,name,position").order("name").then(({ data }) => {
      setManagers((data as Manager[]) ?? []);
    });
  }, []);

  async function handleUpload() {
    if (files.length === 0) return;
    setBusy(true);
    const { data: userData } = await supabase.auth.getUser();
    const userId = userData.user?.id;
    if (!userId) { toast.error("Не авторизован"); setBusy(false); return; }
    if (!managerName) { toast.error("Выберите менеджера"); setBusy(false); return; }
    if (exceeded) {
      toast.error("Достигнут суточный лимит загрузок. Обратитесь к администратору.");
      setBusy(false);
      return;
    }
    if (remaining !== null && files.length > remaining) {
      toast.error(`Можно загрузить ещё ${remaining} из суточного лимита. Уберите лишние файлы.`);
      setBusy(false);
      return;
    }

    let ok = 0;
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      setProgress({ current: i + 1, total: files.length, waiting: 0 });
      try {
        const path = `${userId}/${Date.now()}-${file.name}`;
        const { error: upErr } = await supabase.storage.from("call-audio").upload(path, file);
        if (upErr) throw upErr;

        const { data: insertData, error: insErr } = await supabase
          .from("calls")
          .insert({
            uploaded_by: userId,
            manager_name: managerName || null,
            file_name: file.name,
            storage_path: path,
            status: "pending",
          })
          .select("id")
          .single();
        if (insErr) throw insErr;

        const { error: processErr } = await supabase.functions.invoke("process-call", { body: { callId: insertData.id } });
        if (processErr) {
          await supabase
            .from("calls")
            .update({ status: "error", error_message: `Не удалось запустить обработку: ${processErr.message}` })
            .eq("id", insertData.id);
          throw processErr;
        }
        ok++;
      } catch (e: unknown) {
        toast.error(`${file.name}: ${e instanceof Error ? e.message : "ошибка"}`);
      }

      // Pause between files to avoid hitting Gemini RPM quota
      if (i < files.length - 1 && delaySeconds > 0) {
        for (let s = delaySeconds; s > 0; s--) {
          setProgress({ current: i + 1, total: files.length, waiting: s });
          await new Promise(r => setTimeout(r, 1000));
        }
      }
    }
    setBusy(false);
    setProgress(null);
    reloadUsage();
    if (ok > 0) {
      await logActivity("call.upload", { metadata: { count: ok, manager: managerName } });
      toast.success(`Загружено: ${ok}. Обработка началась.`);
      navigate({ to: "/ai-analysis" });
    }
  }

  return (
    <div className="p-8 max-w-3xl mx-auto">
      <header className="mb-8">
        <h1 className="text-3xl font-bold">Загрузка звонков</h1>
        <p className="text-muted-foreground mt-1">Аудиофайлы будут транскрибированы и проанализированы</p>
      </header>

      <Card>
        <CardHeader>
          <CardTitle>Новые звонки</CardTitle>
          <CardDescription>Поддерживаются mp3, wav, m4a и др. Макс. 25 МБ на файл (Whisper API).</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {usage && (
            <div className={`p-3 rounded-md border text-sm flex items-start gap-2 ${exceeded ? "border-destructive bg-destructive/10 text-destructive" : "bg-secondary"}`}>
              <AlertCircle className="size-4 mt-0.5 shrink-0" />
              <div>
                {usage.daily_limit === null ? (
                  <>Суточный лимит: <strong>без ограничений</strong>. Сегодня загружено: {usage.used}.</>
                ) : exceeded ? (
                  <>Суточный лимит исчерпан: <strong>{usage.used}/{usage.daily_limit}</strong>. Загрузка новых звонков запрещена до завтра. Обратитесь к администратору, если нужно увеличить лимит.</>
                ) : (
                  <>Сегодня использовано: <strong>{usage.used}/{usage.daily_limit}</strong>. Осталось: <strong>{remaining}</strong> звонков.</>
                )}
              </div>
            </div>
          )}
          <div className="space-y-2">
            <Label htmlFor="manager">Менеджер</Label>
            {managers.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                Список менеджеров пуст. <Link to="/sales-team" className="text-primary underline">Добавьте менеджера в «Отдел продаж»</Link>.
              </p>
            ) : (
              <Select value={managerName} onValueChange={setManagerName}>
                <SelectTrigger id="manager"><SelectValue placeholder="Выберите менеджера" /></SelectTrigger>
                <SelectContent>
                  {managers.map(m => (
                    <SelectItem key={m.id} value={m.name}>
                      {m.name}{m.position ? ` — ${m.position}` : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>

          <div
            onClick={() => inputRef.current?.click()}
            className="border-2 border-dashed rounded-lg p-10 text-center cursor-pointer hover:border-primary/50 hover:bg-accent/50 transition"
          >
            <UploadIcon className="size-10 mx-auto text-muted-foreground mb-3" />
            <p className="font-medium">Нажмите чтобы выбрать файлы</p>
            <p className="text-sm text-muted-foreground mt-1">или перетащите сюда</p>
            <input
              ref={inputRef}
              type="file"
              multiple
              accept="audio/*,.mp3,.wav,.m4a,.ogg,.oga,.aac,.flac,.webm,.mp4,.opus,.amr,.3gp"
              hidden
              onChange={e => setFiles(Array.from(e.target.files ?? []))}
            />
          </div>

          {files.length > 0 && (
            <div className="space-y-2">
              {files.map((f, i) => (
                <div key={i} className="flex items-center gap-3 p-3 bg-secondary rounded-md">
                  <FileAudio className="size-4 text-muted-foreground" />
                  <span className="flex-1 text-sm truncate">{f.name}</span>
                  <span className="text-xs text-muted-foreground">{(f.size / 1024 / 1024).toFixed(1)} МБ</span>
                  <button onClick={() => setFiles(files.filter((_, j) => j !== i))} className="text-muted-foreground hover:text-foreground">
                    <X className="size-4" />
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="delay">Пауза между файлами: {delaySeconds} сек</Label>
            <input
              id="delay"
              type="range"
              min={0}
              max={60}
              step={5}
              value={delaySeconds}
              onChange={e => setDelaySeconds(Number(e.target.value))}
              className="w-full"
              disabled={busy}
            />
            <p className="text-xs text-muted-foreground">
              Google Gemini имеет лимит запросов в минуту (RPM). Для бесплатного тира Gemini 2.5 Flash рекомендуется 15+ сек, для Pro — 30+ сек. Каждый звонок = 2 запроса (транскрибация + анализ).
            </p>
          </div>

          {progress && (
            <div className="p-3 bg-secondary rounded-md text-sm">
              {progress.waiting > 0
                ? `Пауза перед следующим файлом: ${progress.waiting} сек (${progress.current}/${progress.total})`
                : `Обработка ${progress.current} из ${progress.total}…`}
            </div>
          )}

          <Button onClick={handleUpload} disabled={busy || files.length === 0 || exceeded} className="w-full" size="lg">
            {busy ? "Загрузка…" : exceeded ? "Лимит исчерпан" : `Загрузить и проанализировать (${files.length})`}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
