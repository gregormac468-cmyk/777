import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Upload, FileAudio, RefreshCw, TrendingUp, BarChart3, Users as UsersIcon, Trophy, CalendarIcon } from "lucide-react";
import { format, startOfDay, endOfDay, startOfMonth, startOfQuarter, startOfYear, subMonths, subDays } from "date-fns";
import { ru } from "date-fns/locale";
import { cn, normalizeScore } from "@/lib/utils";
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  AreaChart,
  Area,
  ReferenceLine,
  LabelList,
} from "recharts";

export const Route = createFileRoute("/_app/")({
  component: Dashboard,
});

type Criterion = { name: string; score: number; comment?: string };
type Analysis = {
  overall_score?: number;
  summary?: string;
  call_type?: string;
  criteria?: Criterion[];
};
type Call = {
  id: string;
  manager_name: string | null;
  status: string;
  created_at: string;
  analysis: Analysis | null;
};

type Preset = "today" | "month" | "quarter" | "year" | "custom";

function scoreColor(s: number) {
  if (s >= 7) return "text-emerald-600 dark:text-emerald-400";
  if (s >= 4) return "text-amber-600 dark:text-amber-400";
  return "text-red-600 dark:text-red-400";
}

function wrapWords(text: string, maxChars: number, maxLines: number): string[] {
  const words = text.split(/\s+/);
  const lines: string[] = [];
  let cur = "";
  for (const w of words) {
    const next = cur ? cur + " " + w : w;
    if (next.length <= maxChars) { cur = next; }
    else {
      if (cur) lines.push(cur);
      cur = w;
      if (lines.length === maxLines - 1) break;
    }
  }
  if (cur && lines.length < maxLines) lines.push(cur);
  if (lines.length === maxLines) {
    // append remaining words to last line, truncated
    const idx = words.indexOf(lines[maxLines - 1].split(" ").pop() || "");
    const rest = idx >= 0 ? words.slice(idx + 1).join(" ") : "";
    if (rest) {
      const last = lines[maxLines - 1] + " " + rest;
      lines[maxLines - 1] = last.length > maxChars ? last.slice(0, maxChars - 1) + "…" : last;
    }
  }
  return lines;
}

function WrapTick({ x, y, payload, maxChars = 20, maxLines = 2 }: any) {
  const lines = wrapWords(String(payload.value ?? ""), maxChars, maxLines);
  const lh = 12;
  const startDy = -((lines.length - 1) * lh) / 2;
  return (
    <g transform={`translate(${x},${y})`}>
      <text textAnchor="end" fill="var(--muted-foreground)" fontSize={11}>
        {lines.map((ln, i) => (
          <tspan key={i} x={-6} dy={i === 0 ? startDy : lh}>{ln}</tspan>
        ))}
      </text>
    </g>
  );
}

function Dashboard() {
  const [calls, setCalls] = useState<Call[]>([]);
  const [loading, setLoading] = useState(true);
  const [preset, setPreset] = useState<Preset>("today");
  const [from, setFrom] = useState<Date | undefined>(startOfDay(new Date()));
  const [to, setTo] = useState<Date | undefined>(endOfDay(new Date()));

  function applyPreset(p: Preset) {
    setPreset(p);
    const now = new Date();
    if (p === "today") { setFrom(startOfDay(now)); setTo(endOfDay(now)); }
    else if (p === "month") { setFrom(startOfMonth(now)); setTo(now); }
    else if (p === "quarter") { setFrom(startOfQuarter(now)); setTo(now); }
    else if (p === "year") { setFrom(startOfYear(now)); setTo(now); }
  }

  async function load() {
    setLoading(true);
    const { data } = await supabase
      .from("calls")
      .select("id, manager_name, status, created_at, analysis")
      .order("created_at", { ascending: false });
    setCalls((data as Call[]) ?? []);
    setLoading(false);
  }

  useEffect(() => {
    load();
    const channel = supabase
      .channel("calls-changes-dash")
      .on("postgres_changes", { event: "*", schema: "public", table: "calls" }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  const filtered = useMemo(() => {
    return calls.filter(c => {
      const t = new Date(c.created_at).getTime();
      if (from && t < from.getTime()) return false;
      if (to && t > to.getTime() + 24 * 3600 * 1000) return false;
      return true;
    });
  }, [calls, from, to]);

  const stats = useMemo(() => {
    const withScore = filtered.map(c => ({ c, s: normalizeScore(c.analysis?.overall_score) }));
    const analyzed = withScore.filter((x): x is { c: typeof filtered[number]; s: number } => x.s != null);
    const total = filtered.length;
    const avg = analyzed.length
      ? analyzed.reduce((s, x) => s + x.s, 0) / analyzed.length
      : null;

    // Per manager: call count + avg score
    const byMgr = new Map<string, { sum: number; scored: number; count: number }>();
    withScore.forEach(({ c, s }) => {
      const key = c.manager_name?.trim() || "Без имени";
      const cur = byMgr.get(key) ?? { sum: 0, scored: 0, count: 0 };
      cur.count += 1;
      if (s != null) {
        cur.sum += s;
        cur.scored += 1;
      }
      byMgr.set(key, cur);
    });
    const managerCounts = Array.from(byMgr.entries())
      .map(([name, v]) => ({ name, count: v.count }))
      .sort((a, b) => b.count - a.count);
    const managerAvg = Array.from(byMgr.entries())
      .filter(([, v]) => v.scored > 0)
      .map(([name, v]) => ({ name, avg: +(v.sum / v.scored).toFixed(2) }))
      .sort((a, b) => b.avg - a.avg);

    // Calls per day
    const byDay = new Map<string, number>();
    filtered.forEach(c => {
      const day = format(new Date(c.created_at), "yyyy-MM-dd");
      byDay.set(day, (byDay.get(day) ?? 0) + 1);
    });
    const trend = Array.from(byDay.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([day, count]) => ({ day, count, label: format(new Date(day), "dd.MM.yyyy", { locale: ru }) }));

    return { total, avg, managerCounts, managerAvg, trend, managersTotal: byMgr.size };
  }, [filtered]);

  const presets: { key: Preset; label: string }[] = [
    { key: "today", label: "Сегодня" },
    { key: "month", label: "Месяц" },
    { key: "quarter", label: "Квартал" },
    { key: "year", label: "Год" },
  ];

  return (
    <div className="p-4 sm:p-6 md:p-8 max-w-6xl mx-auto">
      <header className="flex flex-wrap items-start justify-between gap-3 mb-6">
        <div className="min-w-0">
          <h1 className="text-2xl sm:text-3xl font-bold">Дашборд</h1>
          <p className="text-sm sm:text-base text-muted-foreground mt-1">Аналитика разговоров менеджеров</p>
        </div>
        <div className="flex gap-2 shrink-0">
          <Button variant="outline" size="icon" onClick={load}><RefreshCw className="size-4" /></Button>
          <Link to="/upload"><Button><Upload className="size-4 mr-2" />Загрузить</Button></Link>
        </div>
      </header>

      {/* Time filter */}
      <Card className="mb-6">
        <CardContent className="p-3 sm:p-4 space-y-3">
          <div className="flex flex-wrap gap-2">
            {presets.map(p => (
              <Button
                key={p.key}
                size="sm"
                variant={preset === p.key ? "default" : "outline"}
                onClick={() => applyPreset(p.key)}
              >
                {p.label}
              </Button>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs text-muted-foreground w-full sm:w-auto">Свободная дата:</span>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className={cn("flex-1 sm:flex-none min-w-0", !from && "text-muted-foreground")}>
                  <CalendarIcon className="size-4 mr-1 shrink-0" />
                  <span className="truncate">{from ? format(from, "d MMM yyyy", { locale: ru }) : "С"}</span>
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={from}
                  onSelect={(d) => { setFrom(d); setPreset("custom"); }}
                  initialFocus
                  className={cn("p-3 pointer-events-auto")}
                />
              </PopoverContent>
            </Popover>
            <span className="text-muted-foreground text-sm">—</span>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className={cn("flex-1 sm:flex-none min-w-0", !to && "text-muted-foreground")}>
                  <CalendarIcon className="size-4 mr-1 shrink-0" />
                  <span className="truncate">{to ? format(to, "d MMM yyyy", { locale: ru }) : "По"}</span>
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={to}
                  onSelect={(d) => { setTo(d); setPreset("custom"); }}
                  initialFocus
                  className={cn("p-3 pointer-events-auto")}
                />
              </PopoverContent>
            </Popover>
          </div>
        </CardContent>
      </Card>

      {loading ? (
        <div className="text-center text-muted-foreground py-12">Загрузка…</div>
      ) : filtered.length === 0 ? (
        <Card><CardContent className="py-16 text-center">
          <FileAudio className="size-12 mx-auto text-muted-foreground mb-4" />
          <p className="text-muted-foreground">Нет данных за выбранный период</p>
        </CardContent></Card>
      ) : (
        <>
          {/* Summary cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <FileAudio className="size-7 text-primary shrink-0" />
                <div>
                  <div className="text-2xl font-bold leading-none">{stats.total}</div>
                  <div className="text-xs text-muted-foreground mt-1">Всего звонков</div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <TrendingUp className="size-7 text-emerald-500 shrink-0" />
                <div>
                  <div className={`text-2xl font-bold leading-none ${stats.avg != null ? scoreColor(stats.avg) : ""}`}>
                    {stats.avg != null ? stats.avg.toFixed(1) : "—"}
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">Средняя оценка</div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <UsersIcon className="size-7 text-primary shrink-0" />
                <div>
                  <div className="text-2xl font-bold leading-none">{stats.managersTotal}</div>
                  <div className="text-xs text-muted-foreground mt-1">Менеджеров</div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Calls per manager */}
          {stats.managerCounts.length > 0 && (
            <Card className="mb-6 bg-slate-900 border-slate-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2 text-white justify-center"><BarChart3 className="size-4" />Количество звонков по менеджерам</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-72 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={stats.managerCounts} margin={{ top: 28, right: 24, left: 8, bottom: 8 }} barCategoryGap="30%">
                      <defs>
                        <linearGradient id="gradCalls" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#fbbf24" />
                          <stop offset="50%" stopColor="#fb923c" />
                          <stop offset="100%" stopColor="#ec4899" />
                        </linearGradient>
                      </defs>
                      <XAxis dataKey="name" tick={{ fontSize: 12, fill: "#fff", fontWeight: 600 }} interval={0} axisLine={false} tickLine={false} />
                      <YAxis hide domain={[0, "dataMax + 2"]} />
                      <Tooltip
                        cursor={{ fill: "rgba(255,255,255,0.05)" }}
                        contentStyle={{ background: "#1e293b", color: "#fff", border: "1px solid #334155", borderRadius: 8, fontSize: 12 }}
                        formatter={(v: number) => [v, "Звонков"]}
                      />
                      <Bar dataKey="count" fill="url(#gradCalls)" radius={[20, 20, 20, 20]} barSize={22}>
                        <LabelList dataKey="count" position="top" fill="#fbbf24" fontSize={13} fontWeight={700} offset={10} />
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Avg score per manager */}
          {stats.managerAvg.length > 0 && (
            <Card className="mb-6 bg-slate-900 border-slate-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2 text-white justify-center"><Trophy className="size-4" />Средняя оценка по менеджерам</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-72 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={stats.managerAvg} margin={{ top: 28, right: 24, left: 8, bottom: 8 }} barCategoryGap="30%">
                      <defs>
                        <linearGradient id="gradAvg" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#a78bfa" />
                          <stop offset="50%" stopColor="#8b5cf6" />
                          <stop offset="100%" stopColor="#d946ef" />
                        </linearGradient>
                      </defs>
                      <XAxis dataKey="name" tick={{ fontSize: 12, fill: "#fff", fontWeight: 600 }} interval={0} axisLine={false} tickLine={false} />
                      <YAxis hide domain={[0, 10]} />
                      <Tooltip
                        cursor={{ fill: "rgba(255,255,255,0.05)" }}
                        contentStyle={{ background: "#1e293b", color: "#fff", border: "1px solid #334155", borderRadius: 8, fontSize: 12 }}
                        formatter={(v: number) => [`${v}/10`, "Средняя"]}
                      />
                      <Bar dataKey="avg" fill="url(#gradAvg)" radius={[20, 20, 20, 20]} barSize={22}>
                        <LabelList dataKey="avg" position="top" fill="#d946ef" fontSize={13} fontWeight={700} offset={10} />
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Calls per day */}
          {stats.trend.length > 0 && (
            <Card className="mb-6 bg-slate-900 border-slate-800">
              <CardHeader className="pb-2">
                <CardTitle className="text-base flex items-center gap-2 text-white justify-center"><BarChart3 className="size-4" />Динамика звонков по дням</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-72 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={stats.trend} margin={{ top: 16, right: 24, left: 0, bottom: 8 }}>
                      <defs>
                        <linearGradient id="gradTrend1" x1="0" y1="0" x2="1" y2="0">
                          <stop offset="0%" stopColor="#a78bfa" stopOpacity={0.7} />
                          <stop offset="100%" stopColor="#3b82f6" stopOpacity={0.7} />
                        </linearGradient>
                        <linearGradient id="gradTrend2" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#8b5cf6" stopOpacity={0.5} />
                          <stop offset="100%" stopColor="#1e293b" stopOpacity={0.05} />
                        </linearGradient>
                      </defs>
                      {stats.trend.map((d, i) => (
                        <ReferenceLine key={i} x={d.label} stroke="#ec4899" strokeDasharray="4 4" strokeOpacity={0.45} />
                      ))}
                      <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={{ stroke: "#475569" }} tickLine={false} />
                      <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} orientation="right" />
                      <Tooltip
                        cursor={{ stroke: "#a78bfa", strokeWidth: 1, strokeDasharray: "3 3" }}
                        contentStyle={{ background: "#1e293b", color: "#fff", border: "1px solid #334155", borderRadius: 8, fontSize: 12 }}
                        formatter={(v: number) => [v, "Звонков"]}
                      />
                      <Area
                        type="monotone"
                        dataKey="count"
                        stroke="url(#gradTrend1)"
                        strokeWidth={2.5}
                        fill="url(#gradTrend2)"
                        dot={{ r: 3, fill: "#a78bfa", stroke: "#fff", strokeWidth: 1 }}
                        activeDot={{ r: 5, fill: "#ec4899", stroke: "#fff", strokeWidth: 2 }}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}

// suppress unused import warning if subMonths/subDays not used
void subMonths; void subDays;
