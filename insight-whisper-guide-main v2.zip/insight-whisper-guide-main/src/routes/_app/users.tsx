import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { adminCreateUser } from "@/lib/admin-users.functions";
import { logActivity } from "@/lib/activity-log";

export const Route = createFileRoute("/_app/users")({
  component: UsersPage,
});

type AppRole = "admin" | "manager" | "head";
type Row = {
  id: string;
  email: string | null;
  full_name: string | null;
  role: AppRole | null;
  daily_limit: number | null;
};

const roleLabels: Record<AppRole, string> = {
  admin: "Админ",
  head: "Руководитель",
  manager: "Менеджер",
};

function UsersPage() {
  const { isAdmin } = useAuth();
  const [rows, setRows] = useState<Row[]>([]);
  const [limitDraft, setLimitDraft] = useState<Record<string, string>>({});

  async function load() {
    const { data: profiles } = await supabase.from("profiles").select("id, email, full_name");
    const { data: roles } = await supabase.from("user_roles").select("user_id, role");
    const { data: limits } = await (supabase as any).from("user_limits").select("user_id, daily_limit");
    const roleMap = new Map((roles ?? []).map(r => [r.user_id, r.role as AppRole]));
    const limitMap = new Map<string, number | null>((limits ?? []).map((l: any) => [l.user_id, l.daily_limit]));
    setRows((profiles ?? []).map(p => ({
      ...p,
      role: roleMap.get(p.id) ?? null,
      daily_limit: limitMap.get(p.id) ?? null,
    })));
  }

  useEffect(() => { if (isAdmin) load(); }, [isAdmin]);

  if (!isAdmin) return <div className="p-8">Доступ только для администраторов.</div>;

  async function setRole(userId: string, role: AppRole) {
    await supabase.from("user_roles").delete().eq("user_id", userId);
    const { error } = await supabase.from("user_roles").insert({ user_id: userId, role });
    if (error) toast.error(error.message);
    else {
      const u = rows.find(r => r.id === userId);
      await logActivity("user.role_change", { entity_type: "user", entity_id: userId, metadata: { email: u?.email, role } });
      toast.success("Роль обновлена"); load();
    }
  }

  async function saveLimit(userId: string) {
    const raw = (limitDraft[userId] ?? "").trim();
    const value = raw === "" ? null : Number(raw);
    if (value !== null && (!Number.isInteger(value) || value < 0)) {
      toast.error("Введите целое число ≥ 0 или оставьте пустым");
      return;
    }
    const { error } = await (supabase as any)
      .from("user_limits")
      .upsert({ user_id: userId, daily_limit: value, updated_at: new Date().toISOString() }, { onConflict: "user_id" });
    if (error) { toast.error(error.message); return; }
    const u = rows.find(r => r.id === userId);
    await logActivity("user.limit_change", { entity_type: "user", entity_id: userId, metadata: { email: u?.email, daily_limit: value } });
    toast.success(value === null ? "Лимит снят" : `Лимит: ${value}/день`);
    setLimitDraft(d => { const n = { ...d }; delete n[userId]; return n; });
    load();
  }

  return (
    <div className="p-4 sm:p-6 md:p-8 max-w-5xl mx-auto">
      <header className="mb-6 sm:mb-8">
        <h1 className="text-2xl sm:text-3xl font-bold">Пользователи</h1>
        <p className="text-sm sm:text-base text-muted-foreground mt-1">Роли и суточные лимиты</p>
      </header>
      <CreateUserCard onCreated={load} />
      <div className="h-4" />
      <Card>
        <CardHeader><CardTitle>Список ({rows.length})</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          {rows.map(r => {
            const draft = limitDraft[r.id];
            const current = r.daily_limit === null ? "" : String(r.daily_limit);
            const value = draft ?? current;
            return (
              <div key={r.id} className="flex flex-col gap-3 p-3 rounded-md border">
                <div className="flex items-start gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <div className="font-medium truncate">{r.full_name || r.email}</div>
                      <Badge variant={r.role === "admin" ? "default" : "secondary"} className="shrink-0">{r.role ? roleLabels[r.role] : "—"}</Badge>
                    </div>
                    <div className="text-xs text-muted-foreground truncate">{r.email}</div>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  {r.role !== "admin" && <Button size="sm" variant="outline" onClick={() => setRole(r.id, "admin")}>Сделать админом</Button>}
                  {r.role !== "head" && <Button size="sm" variant="outline" onClick={() => setRole(r.id, "head")}>Сделать руководителем</Button>}
                  {r.role !== "manager" && <Button size="sm" variant="outline" onClick={() => setRole(r.id, "manager")}>Сделать менеджером</Button>}
                </div>
                <div className="flex flex-wrap items-center gap-2 pt-2 border-t">
                  <label className="text-sm font-medium">Суточный лимит звонков:</label>
                  <Input
                    type="number"
                    min={0}
                    placeholder="без лимита"
                    value={value}
                    onChange={e => setLimitDraft(d => ({ ...d, [r.id]: e.target.value }))}
                    className="w-32"
                  />
                  <Button size="sm" onClick={() => saveLimit(r.id)} disabled={draft === undefined}>
                    Сохранить
                  </Button>
                  <span className="text-xs text-muted-foreground">
                    Текущий: {r.daily_limit === null ? "без ограничений" : `${r.daily_limit}/день`}
                  </span>
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>
    </div>
  );
}

function CreateUserCard({ onCreated }: { onCreated: () => void }) {
  const createUser = useServerFn(adminCreateUser);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [role, setRole] = useState<AppRole>("manager");
  const [busy, setBusy] = useState(false);

  function genPassword() {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
    let p = "";
    const arr = new Uint32Array(12);
    crypto.getRandomValues(arr);
    for (let i = 0; i < 12; i++) p += chars[arr[i] % chars.length];
    setPassword(p);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (password.length < 8) { toast.error("Пароль минимум 8 символов"); return; }
    setBusy(true);
    try {
      await createUser({ data: { email, password, full_name: fullName, role } });
      await logActivity("user.create", { entity_type: "user", metadata: { email, role } });
      toast.success(`Пользователь создан: ${email}`);
      setEmail(""); setPassword(""); setFullName(""); setRole("manager");
      onCreated();
    } catch (err: any) {
      toast.error(err?.message ?? "Не удалось создать пользователя");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card>
      <CardHeader><CardTitle>Создать пользователя</CardTitle></CardHeader>
      <CardContent>
        <form onSubmit={submit} className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1">
            <Label>Email</Label>
            <Input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="client@example.com" />
          </div>
          <div className="space-y-1">
            <Label>Имя (необязательно)</Label>
            <Input value={fullName} onChange={e => setFullName(e.target.value)} placeholder="Иван Иванов" />
          </div>
          <div className="space-y-1 sm:col-span-2">
            <Label>Пароль (мин. 8 символов)</Label>
            <div className="flex gap-2">
              <Input type="text" required minLength={8} value={password} onChange={e => setPassword(e.target.value)} placeholder="придумайте или сгенерируйте" />
              <Button type="button" variant="outline" onClick={genPassword}>Сгенерировать</Button>
            </div>
            <p className="text-xs text-muted-foreground">Передайте логин и пароль клиенту — он войдёт сам.</p>
          </div>
          <div className="space-y-1">
            <Label>Роль</Label>
            <Select value={role} onValueChange={(v) => setRole(v as AppRole)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="manager">Менеджер</SelectItem>
                <SelectItem value="head">Руководитель</SelectItem>
                <SelectItem value="admin">Админ</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-end">
            <Button type="submit" disabled={busy} className="w-full sm:w-auto">
              {busy ? "Создание…" : "Создать"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
