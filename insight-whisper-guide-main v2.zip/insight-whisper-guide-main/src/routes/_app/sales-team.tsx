import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Trash2, Plus, FileAudio, Users, UserPlus } from "lucide-react";
import { toast } from "sonner";
import { Link } from "@tanstack/react-router";
import { normalizeScore } from "@/lib/utils";
import { logActivity } from "@/lib/activity-log";

export const Route = createFileRoute("/_app/sales-team")({
  component: SalesTeamPage,
});

type Manager = { id: string; name: string; position: string | null; created_at: string };
type Call = {
  id: string;
  file_name: string;
  manager_name: string | null;
  status: string;
  created_at: string;
  analysis: { overall_score?: number } | null;
};

type Period = "day" | "month" | "quarter" | "custom";

function periodRange(period: Period, from: string, to: string): { from: Date; to: Date } | null {
  const now = new Date();
  const end = new Date();
  if (period === "day") {
    const start = new Date(now);
    start.setHours(0, 0, 0, 0);
    return { from: start, to: end };
  }
  if (period === "month") {
    const start = new Date(now);
    start.setMonth(start.getMonth() - 1);
    return { from: start, to: end };
  }
  if (period === "quarter") {
    const start = new Date(now);
    start.setMonth(start.getMonth() - 3);
    return { from: start, to: end };
  }
  if (period === "custom" && from && to) {
    const f = new Date(from);
    const t = new Date(to);
    t.setHours(23, 59, 59, 999);
    return { from: f, to: t };
  }
  return null;
}

const statusLabel: Record<string, { label: string; cls: string }> = {
  pending: { label: "В очереди", cls: "bg-muted text-muted-foreground" },
  transcribing: { label: "Транскрипция", cls: "bg-blue-100 text-blue-700" },
  analyzing: { label: "Анализ", cls: "bg-purple-100 text-purple-700" },
  done: { label: "Готово", cls: "bg-green-100 text-green-700" },
  error: { label: "Ошибка", cls: "bg-red-100 text-red-700" },
};

function SalesTeamPage() {
  const { isAdmin } = useAuth();
  const [managers, setManagers] = useState<Manager[]>([]);
  const [calls, setCalls] = useState<Call[]>([]);
  const [newName, setNewName] = useState("");
  const [newRole, setNewRole] = useState<string>("Менеджер");
  const [addOpen, setAddOpen] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [period, setPeriod] = useState<Period>("month");
  const [customFrom, setCustomFrom] = useState("");
  const [customTo, setCustomTo] = useState("");
  const [loading, setLoading] = useState(false);

  async function loadManagers() {
    const { data, error } = await supabase.from("managers").select("*").order("name");
    if (error) { toast.error(error.message); return; }
    setManagers((data as Manager[]) ?? []);
  }

  useEffect(() => { loadManagers(); }, []);

  const selected = useMemo(() => managers.find(m => m.id === selectedId) ?? null, [managers, selectedId]);

  async function loadCalls() {
    if (!selected) { setCalls([]); return; }
    const range = periodRange(period, customFrom, customTo);
    if (!range) { setCalls([]); return; }
    setLoading(true);
    const { data, error } = await supabase
      .from("calls")
      .select("id, file_name, manager_name, status, created_at, analysis")
      .eq("manager_name", selected.name)
      .gte("created_at", range.from.toISOString())
      .lte("created_at", range.to.toISOString())
      .order("created_at", { ascending: false });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    setCalls((data as Call[]) ?? []);
  }

  useEffect(() => { loadCalls(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [selectedId, period, customFrom, customTo]);

  async function addManager() {
    if (!newName.trim()) { toast.error("Введите имя"); return; }
    const { data: u } = await supabase.auth.getUser();
    const { data: ins, error } = await supabase.from("managers").insert({
      name: newName.trim(),
      position: newRole,
      created_by: u.user?.id ?? null,
    }).select("id").single();
    if (error) { toast.error(error.message); return; }
    await logActivity("manager.create", { entity_type: "manager", entity_id: ins?.id, metadata: { name: newName.trim(), position: newRole } });
    toast.success("Сотрудник добавлен");
    setNewName(""); setNewRole("Менеджер"); setAddOpen(false);
    loadManagers();
  }

  async function removeManager(id: string) {
    if (!confirm("Удалить менеджера? История его звонков сохранится.")) return;
    const m = managers.find(x => x.id === id);
    const { error } = await supabase.from("managers").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    await logActivity("manager.delete", { entity_type: "manager", entity_id: id, metadata: { name: m?.name } });
    toast.success("Удалено");
    if (selectedId === id) setSelectedId(null);
    loadManagers();
  }

  const avgScore = useMemo(() => {
    const scores = calls.map(c => normalizeScore(c.analysis?.overall_score)).filter((x): x is number => typeof x === "number");
    if (scores.length === 0) return null;
    return scores.reduce((a, b) => a + b, 0) / scores.length;
  }, [calls]);

  return (
    <div className="p-4 md:p-8 max-w-6xl mx-auto w-full overflow-x-hidden">
      <header className="mb-8 flex items-center gap-3">
        <div className="size-10 rounded-lg bg-primary/10 grid place-items-center">
          <Users className="size-5 text-primary" />
        </div>
        <div>
          <h1 className="text-3xl font-bold">Отдел продаж</h1>
          <p className="text-muted-foreground mt-1">Менеджеры и история их звонков</p>
        </div>
      </header>

      <div className="grid lg:grid-cols-[280px_minmax(0,1fr)] gap-6">
        <div className="space-y-4 min-w-0">
          <Button
            onClick={() => setAddOpen(true)}
            className="w-full bg-green-600 hover:bg-green-700 text-white"
          >
            <UserPlus className="size-4 mr-1" />Добавить сотрудника
          </Button>

          <Dialog open={addOpen} onOpenChange={setAddOpen}>
            <DialogContent>
              <DialogHeader><DialogTitle>Новый сотрудник</DialogTitle></DialogHeader>
              <div className="space-y-3 py-2">
                <div className="space-y-1">
                  <label className="text-xs text-muted-foreground">Имя</label>
                  <Input placeholder="ФИО" value={newName} onChange={e => setNewName(e.target.value)} />
                </div>
                <div className="space-y-1">
                  <label className="text-xs text-muted-foreground">Должность</label>
                  <Select value={newRole} onValueChange={setNewRole}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Менеджер">Менеджер</SelectItem>
                      <SelectItem value="Руководитель">Руководитель</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setAddOpen(false)}>Отмена</Button>
                <Button onClick={addManager} className="bg-green-600 hover:bg-green-700 text-white">
                  <Plus className="size-4 mr-1" />Добавить
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <div className="space-y-2">
            <label className="text-xs text-muted-foreground">Сотрудник ({managers.length})</label>
            <Select value={selectedId ?? ""} onValueChange={(v) => setSelectedId(v)}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder={managers.length === 0 ? "Список пуст" : "Выберите сотрудника"} />
              </SelectTrigger>
              <SelectContent>
                {managers.map(m => (
                  <SelectItem key={m.id} value={m.id}>
                    {m.name}{m.position ? ` — ${m.position}` : ""}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {isAdmin && selected && (
              <Button variant="outline" size="sm" className="w-full" onClick={() => removeManager(selected.id)}>
                <Trash2 className="size-4 mr-1 text-destructive" />Удалить выбранного
              </Button>
            )}
          </div>
        </div>

        <div className="space-y-4 min-w-0">
          {!selected ? (
            <Card><CardContent className="py-16 text-center text-muted-foreground">
              Выберите менеджера слева, чтобы увидеть историю звонков
            </CardContent></Card>
          ) : (
            <>
              <Card>
                <CardHeader>
                  <CardTitle>{selected.name}</CardTitle>
                  {selected.position && <p className="text-sm text-muted-foreground">{selected.position}</p>}
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-3 items-end">
                    <div className="space-y-1">
                      <label className="text-xs text-muted-foreground">Период</label>
                      <Select value={period} onValueChange={(v) => setPeriod(v as Period)}>
                        <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="day">Сегодня</SelectItem>
                          <SelectItem value="month">За месяц</SelectItem>
                          <SelectItem value="quarter">За квартал</SelectItem>
                          <SelectItem value="custom">Произвольный</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    {period === "custom" && (
                      <>
                        <div className="space-y-1">
                          <label className="text-xs text-muted-foreground">С</label>
                          <Input type="date" value={customFrom} onChange={e => setCustomFrom(e.target.value)} className="w-40" />
                        </div>
                        <div className="space-y-1">
                          <label className="text-xs text-muted-foreground">По</label>
                          <Input type="date" value={customTo} onChange={e => setCustomTo(e.target.value)} className="w-40" />
                        </div>
                      </>
                    )}
                    <div className="ml-auto text-right">
                      <div className="text-xs text-muted-foreground">Звонков / Средняя оценка</div>
                      <div className="text-lg font-semibold">
                        {calls.length} {avgScore != null && <span className="text-primary">· {avgScore.toFixed(1)}</span>}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {loading ? (
                <div className="text-center text-muted-foreground py-8">Загрузка…</div>
              ) : calls.length === 0 ? (
                <Card><CardContent className="py-12 text-center text-muted-foreground">
                  Нет звонков в выбранном периоде
                </CardContent></Card>
              ) : (
                <div className="space-y-2">
                  {calls.map(c => {
                    const st = statusLabel[c.status] ?? statusLabel.pending;
                    return (
                      <Link key={c.id} to="/calls/$callId" params={{ callId: c.id }}>
                        <Card className="hover:border-primary/50 transition cursor-pointer">
                          <CardContent className="p-4 flex items-center gap-4">
                            <div className="size-10 rounded-lg bg-secondary grid place-items-center">
                              <FileAudio className="size-5" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="font-medium truncate">{c.file_name}</div>
                              <div className="text-xs text-muted-foreground mt-0.5">
                                {new Date(c.created_at).toLocaleString("ru-RU")}
                              </div>
                            </div>
                            {(() => { const ns = normalizeScore(c.analysis?.overall_score); return ns != null && (
                              <div className="text-right">
                                <div className="text-2xl font-bold text-primary">{ns.toFixed(1)}</div>
                                <div className="text-xs text-muted-foreground">оценка</div>
                              </div>
                            ); })()}
                            <Badge className={st.cls + " border-0"}>{st.label}</Badge>
                          </CardContent>
                        </Card>
                      </Link>
                    );
                  })}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
