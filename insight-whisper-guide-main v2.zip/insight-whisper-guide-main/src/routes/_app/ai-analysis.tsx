import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sparkles, FileAudio, Plus, FileDown, CalendarIcon, ClipboardList, RotateCw, Trash2, X, CheckCircle2, AlertCircle, Loader2 } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { format } from "date-fns";
import { ru } from "date-fns/locale";
import { cn, normalizeScore } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { useDailyUsage } from "@/hooks/use-daily-usage";
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ReferenceLine,
} from "recharts";

export const Route = createFileRoute("/_app/ai-analysis")({
  component: AiAnalysisPage,
});

type Criterion = { name: string; score: number; comment: string };
type Analysis = {
  call_type?: string;
  overall_score?: number;
  summary?: string;
  criteria?: Criterion[];
  strengths?: string[];
  weaknesses?: string[];
  recommendations?: string[];
};

function scoreColor(s: number) {
  if (s >= 7) return "text-emerald-600 dark:text-emerald-400";
  if (s >= 4) return "text-amber-600 dark:text-amber-400";
  return "text-red-600 dark:text-red-400";
}

type CallItem = {
  id: string;
  file_name: string;
  manager_name: string | null;
  status: string;
  error_message: string | null;
  created_at: string;
  duration_seconds: number | null;
  analysis: Analysis | null;
};

function formatDuration(sec?: number | null): string | null {
  if (sec == null || !isFinite(sec) || sec < 0) return null;
  const s = Math.round(sec);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const ss = s % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return h > 0 ? `${h}:${pad(m)}:${pad(ss)}` : `${m}:${pad(ss)}`;
}

const statusLabel: Record<string, { label: string; cls: string }> = {
  pending: { label: "В очереди", cls: "bg-muted text-muted-foreground" },
  transcribing: { label: "Транскрипция", cls: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300" },
  analyzing: { label: "Анализ", cls: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300" },
  done: { label: "Готово", cls: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300" },
  error: { label: "Ошибка", cls: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300" },
};

type CallTypeKey = "result" | "secure" | "fail" | "other";
function classifyCallType(type?: string): CallTypeKey {
  if (!type) return "other";
  const t = type.toLowerCase();
  if (t.includes("нерезульт")) return "fail";
  if (t.includes("обеспеч")) return "secure";
  if (t.includes("результат")) return "result";
  return "other";
}
function callTypeStyle(type?: string): { label: string; cls: string } | null {
  const k = classifyCallType(type);
  if (k === "fail") return { label: "Нерезультативный", cls: "bg-red-100 text-red-700 border-red-300 dark:bg-red-900/30 dark:text-red-300 dark:border-red-800" };
  if (k === "secure") return { label: "Обеспечительный", cls: "bg-amber-100 text-amber-800 border-amber-300 dark:bg-amber-900/30 dark:text-amber-300 dark:border-amber-800" };
  if (k === "result") return { label: "Результативный", cls: "bg-emerald-100 text-emerald-700 border-emerald-300 dark:bg-emerald-900/30 dark:text-emerald-300 dark:border-emerald-800" };
  if (!type) return null;
  return { label: type, cls: "bg-muted text-muted-foreground border-border" };
}

const TAB_STORAGE_KEY = "ai-analysis:tab";

function AiAnalysisPage() {
  const { isAdmin, user } = useAuth();
  const { usage, exceeded, remaining } = useDailyUsage(user?.id);
  const [activeName, setActiveName] = useState<string | null>(null);
  const [calls, setCalls] = useState<CallItem[]>([]);
  const [reprocessing, setReprocessing] = useState<Set<string>>(new Set());
  const [tab, setTab] = useState<string>(() => {
    if (typeof window === "undefined") return "calls";
    return sessionStorage.getItem(TAB_STORAGE_KEY) || "calls";
  });

  // Delete-by-date or by selection (admin only)
  const [delDate, setDelDate] = useState<Date>(new Date());
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [confirm2Open, setConfirm2Open] = useState(false);
  const [confirmText, setConfirmText] = useState("");
  const [deleting, setDeleting] = useState(false);
  const [deleteMode, setDeleteMode] = useState<"date" | "selected">("date");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [bulkBusy, setBulkBusy] = useState(false);
  const [reprocessBatch, setReprocessBatch] = useState<string[]>([]);
  const [reprocessLaunched, setReprocessLaunched] = useState<Set<string>>(new Set());
  const [reprocessFailed, setReprocessFailed] = useState<Map<string, string>>(new Map());
  const [reprocessCurrent, setReprocessCurrent] = useState<string | null>(null);

  const dayToDelete = useMemo(() => {
    const d = format(delDate, "yyyy-MM-dd");
    return calls.filter(c => format(new Date(c.created_at), "yyyy-MM-dd") === d);
  }, [calls, delDate]);

  const targetIds = useMemo(() => {
    if (deleteMode === "selected") return Array.from(selected);
    return dayToDelete.map(c => c.id);
  }, [deleteMode, selected, dayToDelete]);

  const targetLabel = deleteMode === "selected"
    ? `выбранные звонки (${targetIds.length})`
    : `звонки за ${format(delDate, "d MMMM yyyy", { locale: ru })}`;

  function toggleOne(id: string) {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }
  function toggleAll() {
    setSelected(prev => prev.size === calls.length ? new Set() : new Set(calls.map(c => c.id)));
  }
  function clearSelection() { setSelected(new Set()); }

  async function performDelete() {
    setDeleting(true);
    try {
      const ids = targetIds;
      if (ids.length === 0) {
        toast.info("Нет звонков для удаления");
        return;
      }
      const { data: rows } = await supabase.from("calls").select("storage_path").in("id", ids);
      const paths = (rows ?? []).map(r => (r as { storage_path: string }).storage_path).filter(Boolean);
      if (paths.length > 0) {
        await supabase.storage.from("call-audio").remove(paths);
      }
      const { error } = await supabase.from("calls").delete().in("id", ids);
      if (error) throw error;
      toast.success(`Удалено звонков: ${ids.length}`);
      setConfirm2Open(false);
      setConfirmOpen(false);
      setConfirmText("");
      clearSelection();
      await loadCalls();
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Не удалось удалить");
    } finally {
      setDeleting(false);
    }
  }

  async function reprocessSelected() {
    const ids = Array.from(selected);
    if (ids.length === 0) return;
    setBulkBusy(true);
    setReprocessBatch(ids);
    setReprocessLaunched(new Set());
    setReprocessFailed(new Map());
    setReprocessCurrent(null);
    try {
      const { error: resetBatchErr } = await supabase.rpc("reset_calls_for_reprocess", { _call_ids: ids });
      if (resetBatchErr) throw resetBatchErr;
      await loadCalls();
      let ok = 0, fail = 0;
      for (const id of ids) {
        setReprocessCurrent(id);
        const { error } = await supabase.functions.invoke("process-call", { body: { callId: id } });
        if (error) {
          fail++;
          setReprocessFailed(prev => { const n = new Map(prev); n.set(id, error.message); return n; });
          await supabase.from("calls")
            .update({ status: "error", error_message: `Не удалось запустить: ${error.message}` })
            .eq("id", id);
        } else {
          ok++;
          setReprocessLaunched(prev => { const n = new Set(prev); n.add(id); return n; });
        }
      }
      setReprocessCurrent(null);
      toast.success(`Перезапущено: ${ok}${fail ? `, ошибок: ${fail}` : ""}`);
      clearSelection();
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Не удалось перезапустить");
    } finally {
      setBulkBusy(false);
    }
  }

  function clearReprocessPanel() {
    setReprocessBatch([]);
    setReprocessLaunched(new Set());
    setReprocessFailed(new Map());
    setReprocessCurrent(null);
  }

  useEffect(() => {
    if (typeof window !== "undefined") sessionStorage.setItem(TAB_STORAGE_KEY, tab);
  }, [tab]);

  async function loadCalls() {
    const { data } = await supabase
      .from("calls")
      .select("id, file_name, manager_name, status, error_message, created_at, duration_seconds, analysis")
      .order("created_at", { ascending: false });
    setCalls((data as CallItem[]) ?? []);
  }

  async function reprocess(e: React.MouseEvent, callId: string) {
    e.preventDefault();
    e.stopPropagation();
    if (reprocessing.has(callId)) return;
    setReprocessing(prev => new Set(prev).add(callId));
    try {
      const { error: updErr } = await supabase.rpc("reset_call_for_reprocess", { _call_id: callId });
      if (updErr) throw updErr;
      await loadCalls();
      const { error } = await supabase.functions.invoke("process-call", { body: { callId } });
      if (error) {
        await supabase
          .from("calls")
          .update({ status: "error", error_message: `Не удалось запустить: ${error.message}` })
          .eq("id", callId);
        throw error;
      }
      toast.success("Повторный анализ запущен");
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Не удалось запустить повторный анализ");
    } finally {
      setReprocessing(prev => {
        const next = new Set(prev);
        next.delete(callId);
        return next;
      });
    }
  }

  useEffect(() => {
    supabase
      .from("instructions")
      .select("name")
      .eq("is_active", true)
      .order("updated_at", { ascending: false })
      .limit(1)
      .maybeSingle()
      .then(({ data }) => setActiveName((data as { name: string } | null)?.name ?? null));

    loadCalls();
    const channel = supabase
      .channel("calls-changes-ai")
      .on("postgres_changes", { event: "*", schema: "public", table: "calls" }, () => loadCalls())
      .subscribe();
    const interval = setInterval(() => loadCalls(), 3000);
    return () => { supabase.removeChannel(channel); clearInterval(interval); };
  }, []);

  return (
    <div className="p-4 sm:p-6 md:p-8 max-w-5xl mx-auto space-y-4 md:space-y-6">
      <header>
        <div className="flex items-start sm:items-center justify-between gap-3 flex-wrap">
          <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-2">
            <Sparkles className="size-6 sm:size-7 text-primary shrink-0" /> Анализ ИИ
          </h1>
          <AiCostBadge calls={calls} isAdmin={isAdmin} />
        </div>
        <p className="text-sm sm:text-base text-muted-foreground mt-1">
          Анализ транскрипта разговора через Gemini на основе инструкции:{" "}
          {activeName ? <span className="font-medium text-foreground">«{activeName}»</span> : "активной"}
        </p>
      </header>

      {usage && (
        <div className={`p-3 rounded-md border text-sm flex items-start gap-2 ${exceeded ? "border-destructive bg-destructive/10 text-destructive" : "bg-secondary"}`}>
          <AlertCircle className="size-4 mt-0.5 shrink-0" />
          <div>
            {usage.daily_limit === null ? (
              <>Суточный лимит: <strong>без ограничений</strong>. Сегодня загружено: {usage.used}.</>
            ) : exceeded ? (
              <>Суточный лимит исчерпан: <strong>{usage.used}/{usage.daily_limit}</strong>. Загрузка новых звонков запрещена до завтра. Обратитесь к администратору.</>
            ) : (
              <>Сегодня использовано: <strong>{usage.used}/{usage.daily_limit}</strong>. Осталось: <strong>{remaining}</strong> звонков.</>
            )}
          </div>
        </div>
      )}


      <Tabs value={tab} onValueChange={setTab} className="w-full">
        <TabsList className="w-full sm:w-auto">
          <TabsTrigger value="calls" className="flex-1 sm:flex-none"><FileAudio className="size-4 mr-1" /> <span className="hidden xs:inline">Загруженные </span>звонки</TabsTrigger>
          <TabsTrigger value="report" className="flex-1 sm:flex-none"><ClipboardList className="size-4 mr-1" /> <span className="hidden xs:inline">Дневной </span>отчёт</TabsTrigger>
        </TabsList>

        <TabsContent value="calls" className="mt-4">
          <Card>
            <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 space-y-0">
              <CardTitle className="text-base flex items-center gap-2 min-w-0">
                <FileAudio className="size-4 shrink-0" /> <span className="truncate">Загруженные звонки ({calls.length})</span>
              </CardTitle>
              <Button asChild size="sm" className="bg-green-600 hover:bg-green-700 text-white w-full sm:w-auto">
                <Link to="/upload">
                  <Plus className="size-4" /> Анализировать ещё
                </Link>
              </Button>
            </CardHeader>
            <CardContent className="px-3 sm:px-6">
              {isAdmin && (
                <div className="mb-3 flex flex-wrap items-center gap-2 p-3 rounded-lg border border-dashed bg-muted/30">
                  <span className="text-xs font-medium text-muted-foreground mr-1">Удалить за дату:</span>
                  <Button variant="outline" size="sm" onClick={() => setDelDate(new Date())}>Сегодня</Button>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" size="sm" className="font-normal">
                        <CalendarIcon className="size-4" />
                        {format(delDate, "d MMM yyyy", { locale: ru })}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar mode="single" selected={delDate} onSelect={(d) => d && setDelDate(d)} initialFocus className={cn("p-3 pointer-events-auto")} locale={ru} />
                    </PopoverContent>
                  </Popover>
                  <span className="text-xs text-muted-foreground">Найдено: <b>{dayToDelete.length}</b></span>
                  <Button
                    variant="destructive"
                    size="sm"
                    className="ml-auto"
                    disabled={dayToDelete.length === 0 || deleting}
                    onClick={() => { setDeleteMode("date"); setConfirmText(""); setConfirmOpen(true); }}
                  >
                    <Trash2 className="size-4" /> Удалить
                  </Button>
                </div>
              )}
              {isAdmin && selected.size > 0 && (
                <div className="mb-3 flex flex-wrap items-center gap-2 p-3 rounded-lg border border-primary/40 bg-primary/5 sticky top-0 z-10">
                  <Button variant="ghost" size="sm" onClick={clearSelection} title="Снять выделение">
                    <X className="size-4" />
                  </Button>
                  <span className="text-sm font-medium">Выбрано: {selected.size}</span>
                  <Button variant="outline" size="sm" onClick={toggleAll}>
                    {selected.size === calls.length ? "Снять все" : "Выбрать все"}
                  </Button>
                  <div className="ml-auto flex flex-wrap items-center gap-2">
                    <Button variant="outline" size="sm" disabled={bulkBusy} onClick={reprocessSelected}>
                      <RotateCw className={`size-4 ${bulkBusy ? "animate-spin" : ""}`} />
                      {bulkBusy ? "Запуск…" : "Перегенерировать"}
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      disabled={deleting}
                      onClick={() => { setDeleteMode("selected"); setConfirmText(""); setConfirmOpen(true); }}
                    >
                      <Trash2 className="size-4" /> Удалить выбранные
                    </Button>
                  </div>
                </div>
              )}
              {reprocessBatch.length > 0 && (() => {
                const total = reprocessBatch.length;
                const byId = new Map(calls.map(c => [c.id, c]));
                const doneCount = reprocessBatch.filter(id => {
                  const s = byId.get(id)?.status;
                  return s === "done" || s === "error";
                }).length;
                const pct = Math.round((doneCount / total) * 100);
                return (
                  <div className="mb-3 p-3 rounded-lg border border-primary/40 bg-card space-y-2">
                    <div className="flex items-center gap-2">
                      <RotateCw className={`size-4 ${bulkBusy ? "animate-spin text-primary" : "text-muted-foreground"}`} />
                      <span className="text-sm font-medium">
                        Перегенерация: {doneCount} / {total}
                      </span>
                      <span className="text-xs text-muted-foreground ml-auto">{pct}%</span>
                      {!bulkBusy && (
                        <Button variant="ghost" size="sm" onClick={clearReprocessPanel} title="Скрыть">
                          <X className="size-4" />
                        </Button>
                      )}
                    </div>
                    <Progress value={pct} />
                    <div className="max-h-48 overflow-auto space-y-1 pr-1">
                      {reprocessBatch.map(id => {
                        const c = byId.get(id);
                        const status = c?.status ?? "pending";
                        const launchFailed = reprocessFailed.has(id);
                        const isCurrent = reprocessCurrent === id;
                        const isDone = status === "done";
                        const isError = status === "error" || launchFailed;
                        const isWorking = status === "transcribing" || status === "analyzing";
                        const st = statusLabel[status] ?? statusLabel.pending;
                        return (
                          <div key={id} className="flex items-center gap-2 text-xs py-1">
                            {isDone ? (
                              <CheckCircle2 className="size-4 text-emerald-500 shrink-0" />
                            ) : isError ? (
                              <AlertCircle className="size-4 text-red-500 shrink-0" />
                            ) : isWorking || isCurrent ? (
                              <Loader2 className="size-4 animate-spin text-primary shrink-0" />
                            ) : (
                              <div className="size-4 rounded-full border-2 border-muted-foreground/30 shrink-0" />
                            )}
                            <span className="truncate flex-1" title={c?.file_name ?? id}>
                              {c?.file_name ?? id.slice(0, 8)}
                            </span>
                            <Badge variant="outline" className={`text-[10px] px-1.5 py-0 ${st.cls}`}>
                              {st.label}
                            </Badge>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })()}
              {calls.length === 0 ? (
                <p className="text-sm text-muted-foreground">Пока нет загруженных звонков.</p>
              ) : (
                <div className="space-y-2 max-h-[60vh] sm:max-h-[420px] overflow-auto pr-1 sm:pr-4">
                  {calls.map(c => {
                    const st = statusLabel[c.status] ?? statusLabel.pending;
                    const sc = normalizeScore(c.analysis?.overall_score);
                    const ct = callTypeStyle(c.analysis?.call_type);
                    const isSelected = selected.has(c.id);
                    return (
                      <div key={c.id} className={`flex items-start sm:items-center flex-wrap gap-x-3 gap-y-2 p-3 rounded-lg border transition ${isSelected ? "border-primary bg-primary/5" : "hover:border-primary/50"}`}>
                        {isAdmin && (
                          <div onClick={(e) => e.stopPropagation()} className="flex items-center pt-0.5 sm:pt-0">
                            <Checkbox
                              checked={isSelected}
                              onCheckedChange={() => toggleOne(c.id)}
                              aria-label="Выбрать звонок"
                            />
                          </div>
                        )}
                        <Link to="/calls/$callId" params={{ callId: c.id }} className="flex items-start sm:items-center gap-3 flex-1 min-w-0">
                          <FileAudio className="size-4 text-muted-foreground shrink-0 mt-0.5 sm:mt-0" />
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-medium truncate" title={c.file_name}>{c.file_name}</div>
                            <div className="text-xs text-muted-foreground truncate">
                              {c.manager_name ?? "—"} · {new Date(c.created_at).toLocaleString("ru-RU")}
                              {formatDuration(c.duration_seconds) && <> · {formatDuration(c.duration_seconds)}</>}
                            </div>
                            {c.status === "error" && c.error_message && (
                              <div className="mt-1 text-xs text-red-600 dark:text-red-400 line-clamp-2" title={c.error_message}>
                                {c.error_message}
                              </div>
                            )}
                          </div>
                        </Link>
                        <div className="flex items-center gap-2 ml-auto shrink-0 flex-wrap justify-end">
                          {ct && (
                            <span className={`text-xs font-medium px-2 py-0.5 rounded-md border whitespace-nowrap ${ct.cls}`}>{ct.label}</span>
                          )}
                          {sc != null && (
                            <div className={`text-base sm:text-lg font-bold ${scoreColor(sc)} tabular-nums w-10 text-right`}>{sc.toFixed(1)}</div>
                          )}
                          <Badge className={st.cls + " border-0 whitespace-nowrap"}>{st.label}</Badge>
                          <button
                            type="button"
                            onClick={(e) => reprocess(e, c.id)}
                            disabled={reprocessing.has(c.id) || c.status === "transcribing" || c.status === "analyzing" || c.status === "pending"}
                            className="inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-md whitespace-nowrap bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300 hover:bg-blue-200 dark:hover:bg-blue-900/50 disabled:opacity-50 disabled:cursor-not-allowed transition"
                            title="Запустить повторный анализ"
                          >
                            <RotateCw className={`size-3 ${reprocessing.has(c.id) ? "animate-spin" : ""}`} />
                            {reprocessing.has(c.id) ? "Запуск…" : "Повторить"}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="report" className="mt-4">
          <DailyReport calls={calls} />
        </TabsContent>
      </Tabs>

      {/* First confirmation */}
      <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Удалить {targetLabel}?</AlertDialogTitle>
            <AlertDialogDescription>
              Будет удалено <b>{targetIds.length}</b> записей вместе с аудиофайлами, транскриптами и анализом. Это действие необратимо.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Отмена</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={(e) => { e.preventDefault(); setConfirmOpen(false); setConfirmText(""); setConfirm2Open(true); }}
            >
              Продолжить
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Second confirmation: type УДАЛИТЬ */}
      <AlertDialog open={confirm2Open} onOpenChange={setConfirm2Open}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Подтвердите удаление</AlertDialogTitle>
            <AlertDialogDescription>
              Для подтверждения введите слово <b>УДАЛИТЬ</b> в поле ниже. Будут безвозвратно удалены {targetIds.length} записей ({targetLabel}).
            </AlertDialogDescription>
          </AlertDialogHeader>
          <Input
            autoFocus
            placeholder="УДАЛИТЬ"
            value={confirmText}
            onChange={(e) => setConfirmText(e.target.value)}
          />
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Отмена</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={confirmText.trim().toUpperCase() !== "УДАЛИТЬ" || deleting}
              onClick={(e) => { e.preventDefault(); performDelete(); }}
            >
              {deleting ? "Удаление…" : "Удалить навсегда"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

const REPORT_DATE_KEY = "ai-analysis:report-date";
const REPORT_MGR_KEY = "ai-analysis:report-manager";
const REPORT_TYPE_KEY = "ai-analysis:report-type";

function DailyReport({ calls }: { calls: CallItem[] }) {
  const [date, setDate] = useState<Date>(() => {
    if (typeof window === "undefined") return new Date();
    const s = sessionStorage.getItem(REPORT_DATE_KEY);
    const d = s ? new Date(s) : new Date();
    return isNaN(d.getTime()) ? new Date() : d;
  });
  const [manager, setManager] = useState<string>(() => {
    if (typeof window === "undefined") return "__all__";
    return sessionStorage.getItem(REPORT_MGR_KEY) || "__all__";
  });
  const [callTypeFilter, setCallTypeFilter] = useState<string>(() => {
    if (typeof window === "undefined") return "__all__";
    return sessionStorage.getItem(REPORT_TYPE_KEY) || "__all__";
  });
  useEffect(() => {
    if (typeof window !== "undefined") sessionStorage.setItem(REPORT_DATE_KEY, date.toISOString());
  }, [date]);
  useEffect(() => {
    if (typeof window !== "undefined") sessionStorage.setItem(REPORT_MGR_KEY, manager);
  }, [manager]);
  useEffect(() => {
    if (typeof window !== "undefined") sessionStorage.setItem(REPORT_TYPE_KEY, callTypeFilter);
  }, [callTypeFilter]);
  const reportRef = useRef<HTMLDivElement>(null);
  const [exporting, setExporting] = useState(false);

  const managers = useMemo(() => {
    const set = new Set<string>();
    calls.forEach(c => { if (c.manager_name) set.add(c.manager_name.trim()); });
    return Array.from(set).sort();
  }, [calls]);

  const dayCalls = useMemo(() => {
    const d = format(date, "yyyy-MM-dd");
    return calls
      .filter(c => format(new Date(c.created_at), "yyyy-MM-dd") === d)
      .filter(c => manager === "__all__" || (c.manager_name?.trim() === manager))
      .filter(c => callTypeFilter === "__all__" || classifyCallType(c.analysis?.call_type) === callTypeFilter)
      .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
  }, [calls, date, manager, callTypeFilter]);

  const stats = useMemo(() => {
    const scored = dayCalls
      .map(c => ({ c, s: normalizeScore(c.analysis?.overall_score) }))
      .filter((x): x is { c: typeof dayCalls[number]; s: number } => x.s != null);
    const avg = scored.length
      ? scored.reduce((s, x) => s + x.s, 0) / scored.length
      : 0;

    let goodScore = 0, midScore = 0, lowScore = 0;
    scored.forEach(({ s }) => {
      if (s >= 7) goodScore++;
      else if (s >= 4) midScore++;
      else lowScore++;
    });
    // calls without score also count as "without result"
    lowScore += dayCalls.length - scored.length;

    let result = 0, secure = 0, fail = 0;
    dayCalls.forEach(c => {
      const k = classifyCallType(c.analysis?.call_type);
      if (k === "result") result++;
      else if (k === "secure") secure++;
      else if (k === "fail") fail++;
    });

    // Hourly average score
    const byHour = new Map<number, { sum: number; count: number }>();
    scored.forEach(({ c, s }) => {
      const h = new Date(c.created_at).getHours();
      const cur = byHour.get(h) ?? { sum: 0, count: 0 };
      cur.sum += s;
      cur.count += 1;
      byHour.set(h, cur);
    });
    const hourly = Array.from(byHour.entries())
      .map(([h, v]) => ({ hour: h, label: `${String(h).padStart(2, "0")}:00`, avg: +(v.sum / v.count).toFixed(2) }))
      .sort((a, b) => a.hour - b.hour);

    return { total: dayCalls.length, avg, goodScore, midScore, lowScore, result, secure, fail, hourly };
  }, [dayCalls]);

  function triggerDownload(blob: Blob, filename: string) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function escapeHtml(s: string): string {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  function buildReportRows() {
    return dayCalls.map(c => {
      const a = c.analysis ?? {};
      return {
        time: format(new Date(c.created_at), "HH:mm"),
        manager: c.manager_name ?? "—",
        file: c.file_name,
        duration: formatDuration(c.duration_seconds) ?? "—",
        type: a.call_type ?? "—",
        score: (() => { const n = normalizeScore(a.overall_score); return n != null ? n.toFixed(1) : "—"; })(),
        summary: a.summary ?? "",
      };
    });
  }

  function downloadDoc() {
    const title = `Дневной отчёт ${format(date, "yyyy-MM-dd")}`;
    const mgr = manager === "__all__" ? "Все менеджеры" : manager;
    const rows = buildReportRows();

    const tableRows = rows.map(r => `
      <tr>
        <td>${escapeHtml(r.time)}</td>
        <td>${escapeHtml(r.manager)}</td>
        <td>${escapeHtml(r.file)}</td>
        <td>${escapeHtml(r.duration)}</td>
        <td>${escapeHtml(r.type)}</td>
        <td>${escapeHtml(r.score)}</td>
        <td>${escapeHtml(r.summary)}</td>
      </tr>`).join("");

    const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
<head><meta charset="utf-8"><title>${escapeHtml(title)}</title>
<style>
  body { font-family: Calibri, Arial, sans-serif; color:#111; }
  h1 { font-size: 20px; }
  h2 { font-size: 14px; margin-top: 18px; }
  table { border-collapse: collapse; width: 100%; font-size: 11px; }
  th, td { border: 1px solid #999; padding: 6px 8px; text-align: left; vertical-align: top; }
  th { background: #f0f0f0; }
  .stats td { width: 25%; }
</style></head>
<body>
  <h1>${escapeHtml(title)}</h1>
  <p><b>Менеджер:</b> ${escapeHtml(mgr)}</p>
  <h2>Сводка</h2>
  <table class="stats">
    <tr><td><b>Всего звонков:</b> ${stats.total}</td><td><b>Средняя оценка:</b> ${stats.avg.toFixed(1)}</td>
        <td><b>Успешные (≥7):</b> ${stats.goodScore}</td><td><b>Обеспечит. (4-7):</b> ${stats.midScore}</td></tr>
    <tr><td><b>Без результата:</b> ${stats.lowScore}</td><td><b>Результативные:</b> ${stats.result}</td>
        <td><b>Обеспечительные:</b> ${stats.secure}</td><td><b>Нерезультативные:</b> ${stats.fail}</td></tr>
  </table>
  <h2>Звонки за день (${rows.length})</h2>
  <table>
    <thead><tr><th>Время</th><th>Менеджер</th><th>Файл</th><th>Длит.</th><th>Тип</th><th>Оценка</th><th>Краткое содержание</th></tr></thead>
    <tbody>${tableRows}</tbody>
  </table>
</body></html>`;

    const blob = new Blob(["\ufeff", html], { type: "application/msword" });
    triggerDownload(blob, `${title}.doc`);
  }

  function downloadXls() {
    const title = `Дневной отчёт ${format(date, "yyyy-MM-dd")}`;
    const mgr = manager === "__all__" ? "Все менеджеры" : manager;
    const rows = buildReportRows();

    const tableRows = rows.map(r => `
      <tr>
        <td>${escapeHtml(r.time)}</td>
        <td>${escapeHtml(r.manager)}</td>
        <td>${escapeHtml(r.file)}</td>
        <td>${escapeHtml(r.duration)}</td>
        <td>${escapeHtml(r.type)}</td>
        <td>${escapeHtml(r.score)}</td>
        <td>${escapeHtml(r.summary)}</td>
      </tr>`).join("");

    const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
<head><meta charset="utf-8"><title>${escapeHtml(title)}</title>
<!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets>
<x:ExcelWorksheet><x:Name>Отчёт</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet>
</x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->
</head>
<body>
  <table border="1">
    <tr><th colspan="7" style="font-size:14pt">${escapeHtml(title)}</th></tr>
    <tr><th colspan="7">Менеджер: ${escapeHtml(mgr)}</th></tr>
    <tr></tr>
    <tr><th colspan="2">Всего звонков</th><td>${stats.total}</td>
        <th colspan="2">Средняя оценка</th><td colspan="2">${stats.avg.toFixed(1)}</td></tr>
    <tr><th colspan="2">Успешные (≥7)</th><td>${stats.goodScore}</td>
        <th colspan="2">Обеспечит. (4-7)</th><td colspan="2">${stats.midScore}</td></tr>
    <tr><th colspan="2">Без результата</th><td>${stats.lowScore}</td>
        <th colspan="2">Результативные</th><td colspan="2">${stats.result}</td></tr>
    <tr><th colspan="2">Обеспечительные</th><td>${stats.secure}</td>
        <th colspan="2">Нерезультативные</th><td colspan="2">${stats.fail}</td></tr>
    <tr></tr>
    <tr><th>Время</th><th>Менеджер</th><th>Файл</th><th>Длит.</th><th>Тип</th><th>Оценка</th><th>Краткое содержание</th></tr>
    ${tableRows}
  </table>
</body></html>`;

    const blob = new Blob(["\ufeff", html], { type: "application/vnd.ms-excel" });
    triggerDownload(blob, `${title}.xls`);
  }

  function downloadPdf() {
    if (!reportRef.current) return;
    setExporting(true);
    try {
      const title = `Дневной отчёт ${format(date, "yyyy-MM-dd")}`;
      const reportHtml = reportRef.current.outerHTML;

      // Inline document styles to preserve appearance in the print window
      const styleTags = Array.from(document.querySelectorAll('style, link[rel="stylesheet"]'))
        .map((el) => el.outerHTML)
        .join("\n");

      const w = window.open("", "_blank", "width=900,height=1000");
      if (!w) {
        alert("Браузер заблокировал всплывающее окно. Разрешите всплывающие окна для этого сайта и попробуйте снова.");
        return;
      }
      w.document.open();
      w.document.write(`<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8" />
<title>${title}</title>
${styleTags}
<style>
  @page { size: A4; margin: 16mm; }
  html, body { background: #ffffff !important; color: #111 !important; }
  body { font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; padding: 0; margin: 0; }
  .print-root { padding: 16px; }
  /* Avoid awkward breaks inside cards/rows */
  .print-root [class*="rounded-lg"] { break-inside: avoid; page-break-inside: avoid; }
  /* Charts: keep SVG visible */
  svg { max-width: 100%; }
  @media print {
    .no-print { display: none !important; }
  }
</style>
</head>
<body>
  <div class="print-root">
    <h1 style="font-size:20px;margin:0 0 12px 0;">${title}</h1>
    ${reportHtml}
  </div>
  <script>
    window.addEventListener('load', function () {
      setTimeout(function () {
        window.focus();
        window.print();
      }, 400);
    });
  </script>
</body>
</html>`);
      w.document.close();
    } catch (e) {
      console.error("PDF export failed:", e);
      alert("Не удалось подготовить отчёт для печати.");
    } finally {
      setExporting(false);
    }
  }

  const ctLabel = (k: CallTypeKey) =>
    k === "result" ? "Результативный" : k === "secure" ? "Обеспечительный" : k === "fail" ? "Без результата" : "—";
  const ctRowCls = (k: CallTypeKey) =>
    k === "result" ? "bg-emerald-50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-900"
    : k === "secure" ? "bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900"
    : k === "fail" ? "bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-900"
    : "bg-card";

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <ClipboardList className="size-4" /> Дневной отчёт
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap items-end gap-3">
          <div>
            <div className="text-xs text-muted-foreground mb-1">Дата</div>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm">
                  <CalendarIcon className="size-4 mr-1" />
                  {format(date, "dd.MM.yyyy")}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar mode="single" selected={date} onSelect={d => d && setDate(d)} initialFocus className={cn("p-3 pointer-events-auto")} />
              </PopoverContent>
            </Popover>
          </div>
          <div className="min-w-[200px]">
            <div className="text-xs text-muted-foreground mb-1">Менеджер</div>
            <Select value={manager} onValueChange={setManager}>
              <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">Все менеджеры</SelectItem>
                {managers.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="min-w-[200px]">
            <div className="text-xs text-muted-foreground mb-1">Тип звонка</div>
            <Select value={callTypeFilter} onValueChange={setCallTypeFilter}>
              <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="__all__">Все типы</SelectItem>
                <SelectItem value="result">Результативные</SelectItem>
                <SelectItem value="secure">Обеспечительные</SelectItem>
                <SelectItem value="fail">Нерезультативные</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="ml-auto flex flex-wrap gap-2">
            <Button onClick={downloadPdf} disabled={exporting} variant="outline">
              <FileDown className="size-4 mr-1" /> {exporting ? "Создание…" : "Скачать PDF"}
            </Button>
            <Button onClick={downloadDoc} variant="outline">
              <FileDown className="size-4 mr-1" /> Скачать DOC
            </Button>
            <Button onClick={downloadXls} variant="outline">
              <FileDown className="size-4 mr-1" /> Скачать Excel
            </Button>
          </div>
        </CardContent>
      </Card>

      <div ref={reportRef} className="bg-background p-2 space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>Отчёт за {format(date, "d MMMM yyyy", { locale: ru })}</CardTitle>
            <p className="text-sm text-muted-foreground">
              Менеджер: {manager === "__all__" ? "Все менеджеры" : manager}
              {callTypeFilter !== "__all__" && (
                <span className="ml-2">
                  · Тип: {" "}
                  {callTypeFilter === "result" ? "Результативные" : callTypeFilter === "secure" ? "Обеспечительные" : callTypeFilter === "fail" ? "Нерезультативные" : callTypeFilter}
                </span>
              )}
            </p>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <StatCard label="Всего звонков" value={stats.total} />
              <StatCard label="Средняя оценка" value={stats.avg.toFixed(1)} />
              <StatCard label="Успешные" value={stats.goodScore} tone="emerald" />
              <StatCard label="Обеспечит." value={stats.midScore} tone="amber" />
              <StatCard label="Без результата" value={stats.lowScore} tone="red" />
              <StatCard label="Результативные" value={stats.result} tone="emeraldOutline" />
              <StatCard label="Обеспечительные" value={stats.secure} tone="amberOutline" />
              <StatCard label="Нерезультативные" value={stats.fail} tone="redOutline" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Качество рабочего дня (средний балл по часам)</CardTitle></CardHeader>
          <CardContent>
            <div className="h-64 w-full">
              {stats.hourly.length === 0 ? (
                <div className="h-full grid place-items-center text-sm text-muted-foreground">Нет данных за выбранный день</div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={stats.hourly} margin={{ top: 8, right: 16, left: -16, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                    <YAxis domain={[0, 10]} ticks={[0, 3, 6, 10]} tick={{ fontSize: 11 }} />
                    <ReferenceLine y={7} stroke="#10b981" strokeDasharray="4 4" />
                    <ReferenceLine y={4} stroke="#f59e0b" strokeDasharray="4 4" />
                    <Tooltip
                      contentStyle={{ background: "var(--popover)", color: "var(--popover-foreground)", border: "1px solid var(--border)", borderRadius: 8, fontSize: 12 }}
                      formatter={(v: number) => [`${v}/10`, "Средняя"]}
                    />
                    <Line type="monotone" dataKey="avg" stroke="#3b82f6" strokeWidth={2} dot={{ r: 4 }} />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Звонки ({dayCalls.length})</CardTitle></CardHeader>
          <CardContent>
            {dayCalls.length === 0 ? (
              <p className="text-sm text-muted-foreground">Нет звонков за выбранный день.</p>
            ) : (
              <div className="space-y-2">
                {dayCalls.map(c => {
                  const k = classifyCallType(c.analysis?.call_type);
                  const sc = normalizeScore(c.analysis?.overall_score);
                  return (
                    <Link key={c.id} to="/calls/$callId" params={{ callId: c.id }} className="block">
                      <div className={cn("flex items-start gap-2 sm:gap-3 p-3 rounded-lg border hover:border-primary/50 transition cursor-pointer", ctRowCls(k))}>
                        <div className="text-xs text-muted-foreground tabular-nums w-10 sm:w-12 shrink-0 pt-0.5">
                          {format(new Date(c.created_at), "HH:mm")}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div className="text-sm font-semibold truncate">{c.manager_name ?? "—"}</div>
                            <div className={cn("text-xl sm:text-2xl font-bold tabular-nums leading-none shrink-0", sc != null ? scoreColor(sc) : "text-muted-foreground")}>
                              {sc != null ? sc.toFixed(1) : "—"}
                            </div>
                          </div>
                          <div className="text-[10px] uppercase tracking-wide text-muted-foreground mt-1">
                            Тип: <span className="font-semibold normal-case text-foreground">{ctLabel(k)}</span>
                          </div>
                          <div className="text-xs text-muted-foreground mt-1 line-clamp-2 break-words">
                            {c.analysis?.summary ?? c.file_name}
                          </div>
                          {formatDuration(c.duration_seconds) && (
                            <div className="text-xs text-muted-foreground mt-0.5">
                              Длительность: {formatDuration(c.duration_seconds)}
                            </div>
                          )}
                        </div>
                      </div>
                    </Link>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatCard({ label, value, tone }: { label: string; value: number | string; tone?: "emerald" | "amber" | "red" | "emeraldOutline" | "amberOutline" | "redOutline" }) {
  const cls =
    tone === "emerald" ? "bg-emerald-50 border-emerald-200 dark:bg-emerald-950/20 dark:border-emerald-900"
    : tone === "amber" ? "bg-amber-50 border-amber-200 dark:bg-amber-950/20 dark:border-amber-900"
    : tone === "red" ? "bg-red-50 border-red-200 dark:bg-red-950/20 dark:border-red-900"
    : tone === "emeraldOutline" ? "border-emerald-300 dark:border-emerald-800"
    : tone === "amberOutline" ? "border-amber-300 dark:border-amber-800"
    : tone === "redOutline" ? "border-red-300 dark:border-red-800"
    : "";
  return (
    <div className={cn("rounded-lg border p-3", cls)}>
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="text-2xl font-bold mt-1 tabular-nums">{value}</div>
    </div>
  );
}

// ============ AI cost estimate badge ============

type AiSettings = {
  analysis_provider: string;
  analysis_model: string;
  transcription_provider: string;
  transcription_model: string;
  token_stats_reset_at: string | null;
};

type TokenBucket = {
  transcriptionInput: number;
  transcriptionOutput: number;
  analysisInput: number;
  analysisOutput: number;
  count: number;
  transcriptionTotal: number;
  analysisTotal: number;
};

function emptyBucket(): TokenBucket {
  return {
    transcriptionInput: 0,
    transcriptionOutput: 0,
    analysisInput: 0,
    analysisOutput: 0,
    count: 0,
    transcriptionTotal: 0,
    analysisTotal: 0,
  };
}

function addCallToBucket(
  b: TokenBucket,
  c: { duration_seconds: number | null; analysis: Analysis | null },
) {
  const dur = c.duration_seconds ?? 0;
  const transcriptTokens = Math.max(200, Math.round((dur / 60) * 200));
  const audioTokens = Math.max(100, Math.round(dur * 32));
  const analysisJson = c.analysis ? JSON.stringify(c.analysis) : "";
  const outTok = Math.max(200, Math.round(analysisJson.length / 4));
  b.transcriptionInput += audioTokens;
  b.transcriptionOutput += transcriptTokens;
  b.analysisInput += transcriptTokens + 300;
  b.analysisOutput += outTok;
  b.count += 1;
  b.transcriptionTotal = b.transcriptionInput + b.transcriptionOutput;
  b.analysisTotal = b.analysisInput + b.analysisOutput;
}

const fmtNum = (n: number) => n.toLocaleString("ru-RU");

function TokenBlock({
  period, periodHint, b, tooltip,
}: { period: string; periodHint: string; b: TokenBucket; tooltip: string }) {
  return (
    <div
      title={tooltip}
      className="flex items-stretch gap-2 rounded-lg border bg-card px-3 py-1.5 text-xs sm:text-sm shadow-sm"
    >
      <div className="flex flex-col pr-3 border-r">
        <span className="text-[10px] uppercase tracking-wide text-muted-foreground">Транскрибация</span>
        <span className="font-semibold tabular-nums">
          ≈ {fmtNum(b.transcriptionTotal)}
          <span className="ml-1 text-muted-foreground font-normal">ток.</span>
        </span>
      </div>
      <div className="flex flex-col pr-3">
        <span className="text-[10px] uppercase tracking-wide text-muted-foreground">Анализ ИИ</span>
        <span className="font-semibold tabular-nums">
          ≈ {fmtNum(b.analysisTotal)}
          <span className="ml-1 text-muted-foreground font-normal">ток.</span>
        </span>
      </div>
      <div className="flex flex-col justify-center pl-2 border-l text-[10px] text-muted-foreground">
        <span className="font-medium text-foreground">{period}</span>
        <span>{periodHint}</span>
        <span>{b.count} звон.</span>
      </div>
    </div>
  );
}

function buildTooltip(label: string, b: TokenBucket, settings: AiSettings) {
  return (
    `${label}\n` +
    `Звонков обработано: ${b.count}\n\n` +
    `Транскрибация (${settings.transcription_model}):\n` +
    `  • вход (аудио): ≈ ${fmtNum(b.transcriptionInput)} ток.\n` +
    `  • выход (текст): ≈ ${fmtNum(b.transcriptionOutput)} ток.\n\n` +
    `Анализ ИИ (${settings.analysis_model}):\n` +
    `  • вход (транскрипт + инструкция): ≈ ${fmtNum(b.analysisInput)} ток.\n` +
    `  • выход (JSON-анализ): ≈ ${fmtNum(b.analysisOutput)} ток.`
  );
}

function PeriodExplorer({ settings }: { settings: AiSettings }) {
  const [from, setFrom] = useState<Date>(() => {
    const d = new Date();
    d.setDate(d.getDate() - 6);
    return d;
  });
  const [to, setTo] = useState<Date>(new Date());
  const [bucket, setBucket] = useState<TokenBucket | null>(null);
  const [loading, setLoading] = useState(false);

  async function compute() {
    setLoading(true);
    try {
      const fromIso = new Date(from.getFullYear(), from.getMonth(), from.getDate()).toISOString();
      const toIso = new Date(to.getFullYear(), to.getMonth(), to.getDate() + 1).toISOString();
      const { data, error } = await supabase
        .from("calls")
        .select("duration_seconds, analysis, status, created_at")
        .eq("status", "done")
        .gte("created_at", fromIso)
        .lt("created_at", toIso)
        .limit(5000);
      if (error) throw error;
      const b = emptyBucket();
      (data ?? []).forEach((c) =>
        addCallToBucket(b, c as { duration_seconds: number | null; analysis: Analysis | null }),
      );
      setBucket(b);
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Не удалось получить статистику");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1.5">
          <CalendarIcon className="size-3.5" /> Период
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-[320px] p-3 space-y-3">
        <div className="text-xs font-medium">Статистика токенов за период</div>
        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1">
            <div className="text-[10px] uppercase text-muted-foreground">С</div>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className="w-full justify-start font-normal">
                  {format(from, "d MMM yyyy", { locale: ru })}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar mode="single" selected={from} onSelect={(d) => d && setFrom(d)} initialFocus className={cn("p-3 pointer-events-auto")} locale={ru} />
              </PopoverContent>
            </Popover>
          </div>
          <div className="space-y-1">
            <div className="text-[10px] uppercase text-muted-foreground">По</div>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className="w-full justify-start font-normal">
                  {format(to, "d MMM yyyy", { locale: ru })}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar mode="single" selected={to} onSelect={(d) => d && setTo(d)} initialFocus className={cn("p-3 pointer-events-auto")} locale={ru} />
              </PopoverContent>
            </Popover>
          </div>
        </div>
        <div className="flex flex-wrap gap-1">
          {[
            { label: "Сегодня", days: 0 },
            { label: "7 дней", days: 6 },
            { label: "30 дней", days: 29 },
          ].map(p => (
            <Button
              key={p.label}
              variant="ghost"
              size="sm"
              className="h-7 text-xs"
              onClick={() => {
                const t = new Date();
                const f = new Date();
                f.setDate(t.getDate() - p.days);
                setFrom(f); setTo(t);
              }}
            >
              {p.label}
            </Button>
          ))}
        </div>
        <Button size="sm" className="w-full" onClick={compute} disabled={loading}>
          {loading ? "Считаю…" : "Показать"}
        </Button>
        {bucket && (
          <div className="pt-1 border-t">
            <TokenBlock
              period="Период"
              periodHint={`${format(from, "d.MM", { locale: ru })} – ${format(to, "d.MM.yy", { locale: ru })}`}
              b={bucket}
              tooltip={buildTooltip(`Оценка токенов за период`, bucket, settings)}
            />
          </div>
        )}
      </PopoverContent>
    </Popover>
  );
}

function AiCostBadge({ calls, isAdmin }: { calls: CallItem[]; isAdmin: boolean }) {
  const [settings, setSettings] = useState<AiSettings | null>(null);
  const [resetting, setResetting] = useState(false);

  async function loadSettings() {
    const { data } = await supabase
      .from("ai_settings")
      .select("analysis_provider, analysis_model, transcription_provider, transcription_model, token_stats_reset_at")
      .limit(1)
      .maybeSingle();
    setSettings((data as AiSettings | null) ?? null);
  }

  useEffect(() => { loadSettings(); }, []);

  const stats = useMemo(() => {
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
    const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const resetAt = settings?.token_stats_reset_at ? new Date(settings.token_stats_reset_at).getTime() : 0;
    const monthFloor = Math.max(monthStart, resetAt);

    const month = emptyBucket();
    const today = emptyBucket();

    calls.forEach(c => {
      if (c.status !== "done") return;
      const t = new Date(c.created_at).getTime();
      if (t >= monthFloor) addCallToBucket(month, c);
      if (t >= Math.max(dayStart, resetAt)) addCallToBucket(today, c);
    });

    return { month, today };
  }, [calls, settings?.token_stats_reset_at]);

  async function handleReset() {
    if (!settings) return;
    setResetting(true);
    try {
      const { error } = await supabase
        .from("ai_settings")
        .update({ token_stats_reset_at: new Date().toISOString() })
        .eq("singleton", true);
      if (error) throw error;
      toast.success("Счётчик токенов за месяц обнулён");
      await loadSettings();
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "Не удалось обнулить");
    } finally {
      setResetting(false);
    }
  }

  if (!settings) return null;

  const monthName = new Date().toLocaleDateString("ru-RU", { month: "long" });
  const resetHint = settings.token_stats_reset_at
    ? `с ${format(new Date(settings.token_stats_reset_at), "d MMM HH:mm", { locale: ru })}`
    : monthName;

  return (
    <div className="flex flex-wrap items-center gap-2">
      <TokenBlock
        period="Сегодня"
        periodHint={new Date().toLocaleDateString("ru-RU")}
        b={stats.today}
        tooltip={buildTooltip(`Оценка токенов за сегодня`, stats.today, settings)}
      />
      <TokenBlock
        period="За месяц"
        periodHint={resetHint}
        b={stats.month}
        tooltip={buildTooltip(`Оценка токенов за месяц (${resetHint})`, stats.month, settings)}
      />
      {isAdmin && (
        <>
          <PeriodExplorer settings={settings} />
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1.5" disabled={resetting}>
                <RotateCw className={`size-3.5 ${resetting ? "animate-spin" : ""}`} /> Обнулить
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Обнулить счётчик токенов за месяц?</AlertDialogTitle>
                <AlertDialogDescription>
                  Месячный счётчик начнёт считать заново с этого момента. Сами звонки и история не удаляются —
                  их по-прежнему можно посмотреть через «Период».
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Отмена</AlertDialogCancel>
                <AlertDialogAction onClick={handleReset}>Обнулить</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </>
      )}
    </div>
  );
}
