import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Upload, Trash2 } from "lucide-react";
import { logActivity } from "@/lib/activity-log";

export const Route = createFileRoute("/_app/instructions")({
  component: InstructionsPage,
});

type Instruction = { id: string; name: string; content: string; is_active: boolean; updated_at: string };

function InstructionsPage() {
  const { isAdmin, isHead } = useAuth();
  const [items, setItems] = useState<Instruction[]>([]);
  const [name, setName] = useState("");
  const [content, setContent] = useState("");
  const [busy, setBusy] = useState(false);

  async function load() {
    const { data } = await supabase.from("instructions").select("*").order("updated_at", { ascending: false });
    const list = (data as Instruction[]) ?? [];
    setItems(list);
    const active = list.find(i => i.is_active);
    if (active) setContent(prev => prev ? prev : active.content);
  }
  useEffect(() => { load(); }, []);

  if (!isAdmin && !isHead) return <div className="p-8">Доступ только для администраторов и руководителей.</div>;

  async function onFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    setName(f.name.replace(/\.[^.]+$/, ""));
    setContent(await f.text());
  }

  async function save() {
    if (!name.trim() || !content.trim()) { toast.error("Заполните название и содержимое"); return; }
    setBusy(true);
    const { data: u } = await supabase.auth.getUser();
    const { data: ins, error } = await supabase.from("instructions").insert({
      name, content, created_by: u.user?.id, is_active: items.length === 0,
    }).select("id").single();
    setBusy(false);
    if (error) return toast.error(error.message);
    await logActivity("instruction.create", { entity_type: "instruction", entity_id: ins?.id, metadata: { name } });
    toast.success("Инструкция сохранена");
    setName(""); setContent(""); load();
  }

  async function activate(id: string) {
    await supabase.from("instructions").update({ is_active: false }).neq("id", id);
    await supabase.from("instructions").update({ is_active: true }).eq("id", id);
    const it = items.find(i => i.id === id);
    await logActivity("instruction.activate", { entity_type: "instruction", entity_id: id, metadata: { name: it?.name } });
    toast.success("Активна");
    load();
  }

  async function remove(id: string) {
    if (!confirm("Удалить инструкцию?")) return;
    const it = items.find(i => i.id === id);
    await supabase.from("instructions").delete().eq("id", id);
    await logActivity("instruction.delete", { entity_type: "instruction", entity_id: id, metadata: { name: it?.name } });
    load();
  }

  return (
    <div className="p-8 max-w-4xl mx-auto space-y-8">
      <header>
        <h1 className="text-3xl font-bold">Инструкции для AI</h1>
        <p className="text-muted-foreground mt-1">Критерии оценки, информация о компании и продукте</p>
      </header>

      <Card>
        <CardHeader><CardTitle>Новая инструкция</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="file" className="cursor-pointer">
              <div className="flex items-center gap-2 text-sm text-primary hover:underline">
                <Upload className="size-4" /> Загрузить из текстового файла
              </div>
              <input id="file" type="file" accept=".txt,.md,text/*" hidden onChange={onFile} />
            </Label>
          </div>
          <div className="space-y-2">
            <Label>Название</Label>
            <Input value={name} onChange={e => setName(e.target.value)} placeholder="Например: Стандарт холодных звонков v2" />
          </div>
          <div className="space-y-2">
            <Label>Содержимое</Label>
            <Textarea value={content} onChange={e => setContent(e.target.value)} rows={12} placeholder="Критерии оценки, описание компании, продукт..." />
          </div>
          <Button onClick={save} disabled={busy}>{busy ? "..." : "Сохранить"}</Button>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <h2 className="text-xl font-semibold">Сохранённые ({items.length})</h2>
        {items.map(i => (
          <Card key={i.id}>
            <CardContent className="p-4 flex items-center gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-medium truncate">{i.name}</span>
                  {i.is_active && <Badge>Активна</Badge>}
                </div>
                <div className="text-xs text-muted-foreground mt-1 line-clamp-1">{i.content.slice(0, 200)}</div>
              </div>
              {!i.is_active && <Button variant="outline" size="sm" onClick={() => activate(i.id)}>Активировать</Button>}
              <Button variant="ghost" size="icon" onClick={() => remove(i.id)}><Trash2 className="size-4" /></Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
