import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Eye, EyeOff, Save, ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/_app/ai-providers")({
  component: AiProvidersPage,
});

type Provider = "lovable" | "openai" | "google" | "deepseek" | "anthropic" | "qwen";
type KeyProvider = "openai" | "google" | "deepseek" | "anthropic" | "qwen";

type Settings = {
  id: string;
  transcription_provider: Provider;
  analysis_provider: Provider;
  transcription_model: string;
  analysis_model: string;
  openai_key_mask: string | null;
  google_key_mask: string | null;
  deepseek_key_mask: string | null;
  anthropic_key_mask: string | null;
  qwen_key_mask: string | null;
};

const GEMINI_MODELS: { value: string; label: string; hint: string }[] = [
  { value: "gemini-2.5-flash", label: "Gemini 2.5 Flash", hint: "Самый стабильный вариант для звонков. Рекомендуется по умолчанию." },
  { value: "gemini-2.5-flash-lite", label: "Gemini 2.5 Flash Lite", hint: "Самая дешёвая и быстрая. Подходит для простых звонков." },
  { value: "gemini-2.5-pro", label: "Gemini 2.5 Pro", hint: "Более точный анализ. Рекомендуем для анализа разговоров." },
  { value: "gemini-pro-latest", label: "Gemini Pro (latest)", hint: "Текущая лучшая Pro-модель Google. Алиас обновляется автоматически." },
  { value: "gemini-3-flash-preview", label: "Gemini 3 Flash (preview)", hint: "Новое поколение, может быть менее стабильно из-за preview-статуса." },
  { value: "gemini-3.1-pro-preview", label: "Gemini 3.1 Pro (preview)", hint: "Самая дорогая preview-модель, часто требует включённых лимитов/биллинга." },
];

const OPENAI_TRANSCRIPTION_MODELS = [
  { value: "whisper-1", label: "Whisper v1", hint: "Классический Whisper. Стабильный и недорогой." },
  { value: "gpt-4o-transcribe", label: "GPT-4o Transcribe", hint: "Новая модель с лучшим качеством распознавания." },
  { value: "gpt-4o-mini-transcribe", label: "GPT-4o Mini Transcribe", hint: "Дешевле GPT-4o Transcribe." },
];

const OPENAI_ANALYSIS_MODELS = [
  { value: "gpt-4o-mini", label: "GPT-4o Mini", hint: "Быстрый и дешёвый. Рекомендуется по умолчанию." },
  { value: "gpt-4o", label: "GPT-4o", hint: "Сбалансированный по качеству и цене." },
  { value: "gpt-4.1", label: "GPT-4.1", hint: "Улучшенная версия для сложных задач." },
  { value: "gpt-4.1-mini", label: "GPT-4.1 Mini", hint: "Дешевле GPT-4.1." },
  { value: "gpt-5", label: "GPT-5", hint: "Флагман. Требует доступа к модели." },
  { value: "gpt-5-mini", label: "GPT-5 Mini", hint: "Дешёвая версия GPT-5." },
];

const DEEPSEEK_MODELS = [
  { value: "deepseek-chat", label: "DeepSeek Chat", hint: "Универсальная модель. Рекомендуется." },
  { value: "deepseek-reasoner", label: "DeepSeek Reasoner", hint: "Модель R1 с рассуждениями. Дороже и медленнее." },
];

const ANTHROPIC_MODELS = [
  { value: "claude-3-5-sonnet-latest", label: "Claude 3.5 Sonnet (latest)", hint: "Самый сбалансированный Claude. Рекомендуется." },
  { value: "claude-3-5-haiku-latest", label: "Claude 3.5 Haiku (latest)", hint: "Быстрая и дешёвая модель." },
  { value: "claude-3-opus-latest", label: "Claude 3 Opus (latest)", hint: "Максимальное качество. Дороже." },
  { value: "claude-sonnet-4-5", label: "Claude Sonnet 4.5", hint: "Новейшее поколение. Требует доступа." },
];

const QWEN_MODELS = [
  { value: "qwen-plus", label: "Qwen Plus", hint: "Сбалансированный. Рекомендуется." },
  { value: "qwen-turbo", label: "Qwen Turbo", hint: "Самый быстрый и дешёвый." },
  { value: "qwen-max", label: "Qwen Max", hint: "Максимальное качество." },
];

function getAnalysisModels(provider: Provider) {
  switch (provider) {
    case "openai": return OPENAI_ANALYSIS_MODELS;
    case "deepseek": return DEEPSEEK_MODELS;
    case "anthropic": return ANTHROPIC_MODELS;
    case "qwen": return QWEN_MODELS;
    default: return GEMINI_MODELS;
  }
}

function getTranscriptionModels(provider: Provider) {
  switch (provider) {
    case "openai": return OPENAI_TRANSCRIPTION_MODELS;
    default: return GEMINI_MODELS;
  }
}

function defaultModelFor(provider: Provider, kind: "transcription" | "analysis") {
  const list = kind === "transcription" ? getTranscriptionModels(provider) : getAnalysisModels(provider);
  return list[0]?.value ?? "gemini-2.5-flash";
}

const PROVIDER_LABELS: Record<KeyProvider, { label: string; placeholder: string; help: string }> = {
  openai: { label: "OpenAI API Key", placeholder: "sk-...", help: "platform.openai.com → API keys" },
  google: { label: "Google AI Studio Key", placeholder: "AIza...", help: "aistudio.google.com/app/apikey" },
  deepseek: { label: "DeepSeek API Key", placeholder: "sk-...", help: "platform.deepseek.com → API Keys" },
  anthropic: { label: "Claude (Anthropic) API Key", placeholder: "sk-ant-...", help: "console.anthropic.com → API Keys" },
  qwen: { label: "Qwen (DashScope) API Key", placeholder: "sk-...", help: "dashscope.console.aliyun.com (или OpenRouter)" },
};

function AiProvidersPage() {
  const { isAdmin } = useAuth();
  const [s, setS] = useState<Settings | null>(null);
  const [show, setShow] = useState<Record<KeyProvider, boolean>>({ openai: false, google: false, deepseek: false, anthropic: false, qwen: false });
  const [inputs, setInputs] = useState<Record<KeyProvider, string>>({ openai: "", google: "", deepseek: "", anthropic: "", qwen: "" });
  const [busy, setBusy] = useState(false);

  async function load() {
    const { data, error } = await supabase
      .from("ai_settings")
      .select("id,transcription_provider,analysis_provider,transcription_model,analysis_model,openai_key_mask,google_key_mask,deepseek_key_mask,anthropic_key_mask,qwen_key_mask")
      .limit(1)
      .maybeSingle();
    if (error) { toast.error(error.message); return; }
    setS(data as unknown as Settings);
    setInputs({ openai: "", google: "", deepseek: "", anthropic: "", qwen: "" });
  }
  useEffect(() => { load(); }, []);

  if (!isAdmin) return <div className="p-8">Доступ только для администраторов.</div>;
  if (!s) return <div className="p-8 text-muted-foreground">Загрузка…</div>;

  async function save() {
    if (!s) return;
    setBusy(true);
    const { data: u } = await supabase.auth.getUser();

    const { error: updErr } = await supabase.from("ai_settings").update({
      transcription_provider: s.transcription_provider,
      analysis_provider: s.analysis_provider,
      transcription_model: s.transcription_model,
      analysis_model: s.analysis_model,
      updated_by: u.user?.id,
    }).eq("id", s.id);
    if (updErr) { setBusy(false); return toast.error(updErr.message); }

    for (const p of Object.keys(inputs) as KeyProvider[]) {
      const val = inputs[p].trim();
      if (!val) continue;
      const { error } = await supabase.rpc("set_ai_provider_key", { _provider: p, _key: val });
      if (error) { setBusy(false); return toast.error(`${p}: ${error.message}`); }
    }

    setBusy(false);
    toast.success("Настройки сохранены");
    load();
  }

  async function clearKey(provider: KeyProvider) {
    if (!confirm("Удалить сохранённый ключ?")) return;
    const { error } = await supabase.rpc("set_ai_provider_key", { _provider: provider, _key: "" });
    if (error) return toast.error(error.message);
    toast.success("Ключ удалён");
    load();
  }

  const masks: Record<KeyProvider, string | null> = {
    openai: s.openai_key_mask,
    google: s.google_key_mask,
    deepseek: s.deepseek_key_mask,
    anthropic: s.anthropic_key_mask,
    qwen: s.qwen_key_mask,
  };

  const providerHasKey = (p: Provider): boolean => {
    if (p === "lovable") return true;
    return !!masks[p as KeyProvider];
  };

  const PROVIDER_NAME: Record<Provider, string> = {
    lovable: "Lovable AI",
    openai: "OpenAI",
    google: "Google Gemini",
    deepseek: "DeepSeek",
    anthropic: "Claude (Anthropic)",
    qwen: "Qwen",
  };

  function changeTranscriptionProvider(v: Provider) {
    const list = getTranscriptionModels(v);
    const keep = list.some(m => m.value === s!.transcription_model);
    setS({ ...s!, transcription_provider: v, transcription_model: keep ? s!.transcription_model : defaultModelFor(v, "transcription") });
  }

  function changeAnalysisProvider(v: Provider) {
    const list = getAnalysisModels(v);
    const keep = list.some(m => m.value === s!.analysis_model);
    setS({ ...s!, analysis_provider: v, analysis_model: keep ? s!.analysis_model : defaultModelFor(v, "analysis") });
  }

  const transcriptionModels = getTranscriptionModels(s.transcription_provider);
  const analysisModels = getAnalysisModels(s.analysis_provider);

  return (
    <div className="p-8 max-w-3xl mx-auto space-y-8">
      <header>
        <h1 className="text-3xl font-bold">AI-провайдеры</h1>
        <p className="text-muted-foreground mt-1">
          Подключите ключи OpenAI, Google, DeepSeek, Claude или Qwen. Ключи хранятся только на сервере, видны исключительно администраторам и никогда не передаются в браузер целиком.
        </p>
      </header>

      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="p-4 space-y-2 text-sm">
          <div className="flex items-start gap-3">
            <ShieldCheck className="size-5 text-primary shrink-0 mt-0.5" />
            <div>
              Ключи защищены RLS-политикой (только роль <b>admin</b>) и используются серверной функцией <code>process-call</code>.
            </div>
          </div>
          <div className="pl-8 grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1 text-xs">
            <div>Активный ключ <b>транскрипции</b>: <span className="font-mono">{PROVIDER_NAME[s.transcription_provider]}</span> {providerHasKey(s.transcription_provider) ? <span className="text-green-600">✓ готов</span> : <span className="text-destructive">— ключ не задан</span>}</div>
            <div>Активный ключ <b>анализа</b>: <span className="font-mono">{PROVIDER_NAME[s.analysis_provider]}</span> {providerHasKey(s.analysis_provider) ? <span className="text-green-600">✓ готов</span> : <span className="text-destructive">— ключ не задан</span>}</div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Транскрипция</CardTitle>
          <CardDescription>Кто превращает аудио в текст. Список моделей зависит от выбранного провайдера.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Select
            value={s.transcription_provider}
            onValueChange={(v) => changeTranscriptionProvider(v as Provider)}
          >
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="lovable">Lovable AI (Gemini, без своего ключа)</SelectItem>
              <SelectItem value="openai">OpenAI Whisper / GPT-4o {masks.openai ? "✓" : "(нужен ключ)"}</SelectItem>
              <SelectItem value="google">Google Gemini {masks.google ? "✓" : "(нужен ключ)"}</SelectItem>
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">
            DeepSeek, Claude и Qwen не поддерживают распознавание аудио — для транскрипции выбирайте Lovable / OpenAI / Google.
          </p>
          <div className="space-y-2">
            <Label>Модель {PROVIDER_NAME[s.transcription_provider]} для транскрипции</Label>
            <Select
              value={s.transcription_model}
              onValueChange={(v) => setS({ ...s, transcription_model: v })}
            >
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {transcriptionModels.map(m => (
                  <SelectItem key={m.value} value={m.value}>
                    <div className="flex flex-col">
                      <span>{m.label}</span>
                      <span className="text-xs text-muted-foreground">{m.hint}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Анализ разговора</CardTitle>
          <CardDescription>Кто оценивает разговор по инструкции. Список моделей зависит от выбранного провайдера.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Select
            value={s.analysis_provider}
            onValueChange={(v) => changeAnalysisProvider(v as Provider)}
          >
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="lovable">Lovable AI (Gemini, без своего ключа)</SelectItem>
              <SelectItem value="openai">OpenAI GPT {masks.openai ? "✓" : "(нужен ключ)"}</SelectItem>
              <SelectItem value="google">Google Gemini {masks.google ? "✓" : "(нужен ключ)"}</SelectItem>
              <SelectItem value="deepseek">DeepSeek {masks.deepseek ? "✓" : "(нужен ключ)"}</SelectItem>
              <SelectItem value="anthropic">Claude (Anthropic) {masks.anthropic ? "✓" : "(нужен ключ)"}</SelectItem>
              <SelectItem value="qwen">Qwen {masks.qwen ? "✓" : "(нужен ключ)"}</SelectItem>
            </SelectContent>
          </Select>
          <div className="space-y-2">
            <Label>Модель {PROVIDER_NAME[s.analysis_provider]} для анализа</Label>
            <Select
              value={s.analysis_model}
              onValueChange={(v) => setS({ ...s, analysis_model: v })}
            >
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {analysisModels.map(m => (
                  <SelectItem key={m.value} value={m.value}>
                    <div className="flex flex-col">
                      <span>{m.label}</span>
                      <span className="text-xs text-muted-foreground">{m.hint}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Ключи API</CardTitle>
          <CardDescription>Сохранённые ключи отображаются маской. Введите новый, чтобы заменить.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {(Object.keys(PROVIDER_LABELS) as KeyProvider[]).map((p) => (
            <div key={p} className="space-y-2">
              <Label>{PROVIDER_LABELS[p].label}</Label>
              <div className="text-xs text-muted-foreground">
                Текущий: {masks[p] ? masks[p] : <span className="italic">не задан</span>} · Где взять: {PROVIDER_LABELS[p].help}
              </div>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Input
                    type={show[p] ? "text" : "password"}
                    value={inputs[p]}
                    onChange={e => setInputs({ ...inputs, [p]: e.target.value })}
                    placeholder={PROVIDER_LABELS[p].placeholder}
                    autoComplete="off"
                  />
                  <button
                    type="button"
                    onClick={() => setShow({ ...show, [p]: !show[p] })}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {show[p] ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                  </button>
                </div>
                {masks[p] && (
                  <Button variant="outline" onClick={() => clearKey(p)}>Удалить</Button>
                )}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={save} disabled={busy} size="lg">
          <Save className="size-4 mr-2" />
          {busy ? "Сохранение…" : "Сохранить настройки"}
        </Button>
      </div>
    </div>
  );
}
