
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const inputSchema = z.object({
  email: z.string().trim().email().max(255),
  password: z.string().min(8).max(72),
  full_name: z.string().trim().max(120).optional().default(""),
  role: z.enum(["admin", "manager", "head"]).default("manager"),
});

export const adminCreateUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => inputSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    // Verify caller is admin
    const { data: roleRow, error: roleErr } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", userId)
      .eq("role", "admin")
      .maybeSingle();
    if (roleErr) {
      console.error("[adminCreateUser] role check error:", roleErr);
      throw new Error("Не удалось проверить права доступа");
    }
    if (!roleRow) throw new Error("Доступ запрещён");

    // Create user via admin API (email auto-confirmed so they can log in immediately)
    const { data: created, error: createErr } = await supabaseAdmin.auth.admin.createUser({
      email: data.email,
      password: data.password,
      email_confirm: true,
      user_metadata: { full_name: data.full_name ?? "" },
    });
    if (createErr) {
      console.error("[adminCreateUser] createUser error:", createErr);
      const msg = /already|registered|exists/i.test(createErr.message ?? "")
        ? "Пользователь с таким email уже существует"
        : "Не удалось создать пользователя";
      throw new Error(msg);
    }
    const newUserId = created.user?.id;
    if (!newUserId) throw new Error("Не удалось создать пользователя");

    // Assign requested role (trigger no longer auto-assigns 'manager')
    await supabaseAdmin.from("user_roles").delete().eq("user_id", newUserId);
    const { error: insErr } = await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: newUserId, role: data.role });
    if (insErr) {
      console.error("[adminCreateUser] role insert error:", insErr);
      throw new Error("Пользователь создан, но не удалось назначить роль");
    }

    return { id: newUserId, email: data.email };
  });
