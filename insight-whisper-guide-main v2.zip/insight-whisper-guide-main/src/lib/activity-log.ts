import { supabase } from "@/integrations/supabase/client";

export type ActivityAction =
  | "instruction.create"
  | "instruction.activate"
  | "instruction.delete"
  | "manager.create"
  | "manager.delete"
  | "call.upload"
  | "user.create"
  | "user.role_change"
  | "user.limit_change";

export async function logActivity(
  action: ActivityAction,
  opts: { entity_type?: string; entity_id?: string | null; metadata?: Record<string, unknown> } = {},
) {
  try {
    const { data } = await supabase.auth.getUser();
    const uid = data.user?.id;
    if (!uid) return;
    await (supabase as any).from("activity_logs").insert({
      user_id: uid,
      action,
      entity_type: opts.entity_type ?? null,
      entity_id: opts.entity_id ?? null,
      metadata: opts.metadata ?? null,
    });
  } catch {
    /* silent */
  }
}
