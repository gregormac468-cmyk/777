import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Нормализует оценку к шкале 0–10. Старые записи могут быть в шкале 0–100. */
export function normalizeScore(score: number | null | undefined): number | null {
  if (score == null || typeof score !== "number" || isNaN(score)) return null;
  if (score > 10) return Math.min(10, score / 10);
  return Math.max(0, score);
}
