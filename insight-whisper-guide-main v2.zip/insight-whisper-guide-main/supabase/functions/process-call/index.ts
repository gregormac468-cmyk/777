// Edge function: transcribe audio + analyze. Provider per ai_settings table.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

type Provider = "lovable" | "openai" | "google" | "deepseek" | "anthropic" | "qwen";

function normalizeGeminiModel(model: string | null | undefined, fallback: string): string {
  const m = (model ?? "").trim();
  if (!m) return fallback;
  if (m === "gemini-flash-latest") return "gemini-2.5-flash";
  if (m === "gemini-pro-latest") return "gemini-2.5-pro";
  if (m === "gemini-3.1-pro") return "gemini-3.1-pro-preview";
  if (m === "gemini-1.5-flash") return "gemini-1.5-flash-latest";
  if (m === "gemini-1.5-pro") return "gemini-1.5-pro-latest";
  return m;
}

function userFriendlyError(message: string): string {
  const m = message || "";
  // Known quota / overload patterns get a tailored hint.
  if (/429|RESOURCE_EXHAUSTED|Quota exceeded|quota|rate limit/i.test(m)) {
    return "Превышен лимит/квота у выбранного AI провайдера. Проверьте тариф и квоту, либо выберите другую модель.";
  }
  if (/503|UNAVAILABLE|overloaded|high demand|temporarily/i.test(m)) {
    return "AI провайдер временно перегружен. Попробуйте повторить позже или выбрать другую модель.";
  }
  if (/401|403|invalid api key|incorrect api key|unauthorized|permission/i.test(m)) {
    return "AI провайдер отклонил запрос: неверный или недостаточно прав API ключ. Проверьте ключ в настройках.";
  }
  if (/timeout|ETIMEDOUT|network|fetch failed/i.test(m)) {
    return "Сетевая ошибка при обращении к AI провайдеру. Попробуйте повторить позже.";
  }
  if (/model|not found|unsupported|does not exist/i.test(m)) {
    return "Выбранная модель недоступна для текущего API ключа. Выберите другую модель в настройках.";
  }
  // App-level validation messages we throw ourselves are safe to surface verbatim.
  if (/API ключ не задан|LOVABLE_API_KEY|не поддерживает транскрипцию|Пустой транскрипт|Call not found|callId is required/i.test(m)) {
    return m;
  }
  // Default: never leak raw provider payloads.
  return "Не удалось обработать звонок: внутренняя ошибка AI провайдера. Подробности в логах сервера.";
}

function guessMime(name: string): string {
  const n = name.toLowerCase();
  if (n.endsWith(".mp3")) return "audio/mpeg";
  if (n.endsWith(".wav")) return "audio/wav";
  if (n.endsWith(".ogg") || n.endsWith(".oga")) return "audio/ogg";
  if (n.endsWith(".m4a") || n.endsWith(".mp4")) return "audio/mp4";
  if (n.endsWith(".webm")) return "audio/webm";
  if (n.endsWith(".flac")) return "audio/flac";
  if (n.endsWith(".aac")) return "audio/aac";
  return "audio/mpeg";
}

async function blobToBase64(blob: Blob): Promise<string> {
  const buf = new Uint8Array(await blob.arrayBuffer());
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < buf.length; i += chunk) {
    binary += String.fromCharCode(...buf.subarray(i, i + chunk));
  }
  return btoa(binary);
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function retryDelayMs(status: number, body: string, attempt: number): number {
  const match = body.match(/"retryDelay"\s*:\s*"(\d+)s"/) ?? body.match(/retry in ([\d.]+)s/i);
  if (match?.[1]) return Math.min(Math.ceil(Number(match[1]) * 1000) + 1000, 65000);
  return status === 429 ? 15000 * (attempt + 1) : 8000 * (attempt + 1);
}

async function fetchGeminiWithRetry(url: string, body: unknown): Promise<any> {
  let lastError = "";
  for (let attempt = 0; attempt < 3; attempt++) {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const text = await res.text();
    if (res.ok) return JSON.parse(text);

    lastError = `Google Gemini ${res.status}: ${text}`;
    if ((res.status === 429 || res.status === 503) && attempt < 2) {
      await sleep(retryDelayMs(res.status, text, attempt));
      continue;
    }
    throw new Error(lastError);
  }
  throw new Error(lastError || "Google Gemini request failed");
}

const ANALYSIS_TOOL = {
  type: "function",
  function: {
    name: "submit_call_analysis",
    description: "Возвращает структурированный анализ звонка",
    parameters: {
      type: "object",
      properties: {
        call_type: { type: "string" },
        overall_score: { type: "number", minimum: 0, maximum: 10, description: "Общая оценка от 0 до 10" },
        summary: { type: "string" },
        criteria: {
          type: "array",
          items: {
            type: "object",
            properties: {
              name: { type: "string" },
              score: { type: "number", minimum: 0, maximum: 10, description: "Оценка критерия от 0 до 10" },
              comment: { type: "string" },
            },
            required: ["name", "score", "comment"],
            additionalProperties: false,
          },
        },
        strengths: { type: "array", items: { type: "string" } },
        weaknesses: { type: "array", items: { type: "string" } },
        recommendations: { type: "array", items: { type: "string" } },
      },
      required: ["call_type", "overall_score", "summary", "criteria", "strengths", "weaknesses", "recommendations"],
      additionalProperties: false,
    },
  },
} as const;

const TRANSCRIBE_SYSTEM =
  "Ты — точный транскрибатор. Верни ПОЛНЫЙ дословный транскрипт аудио на русском языке. Если в аудио есть несколько говорящих, обозначь их как 'Менеджер:' и 'Клиент:'. Не добавляй комментарии, только транскрипт.";

// ---------- Transcription ----------
async function transcribeLovable(apiKey: string, dataUrl: string, model: string): Promise<string> {
  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: `google/${model}`,
      messages: [
        { role: "system", content: TRANSCRIBE_SYSTEM },
        { role: "user", content: [
          { type: "text", text: "Транскрибируй этот звонок дословно." },
          { type: "image_url", image_url: { url: dataUrl } },
        ]},
      ],
    }),
  });
  if (!res.ok) throw new Error(`Lovable AI ${res.status}: ${await res.text()}`);
  const j = await res.json();
  return j.choices?.[0]?.message?.content ?? "";
}

async function transcribeOpenAI(apiKey: string, file: Blob, fileName: string, model: string): Promise<string> {
  const fd = new FormData();
  fd.append("file", file, fileName);
  fd.append("model", model);
  fd.append("language", "ru");
  fd.append("response_format", "text");
  const res = await fetch("https://api.openai.com/v1/audio/transcriptions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}` },
    body: fd,
  });
  if (!res.ok) throw new Error(`OpenAI ${model} ${res.status}: ${await res.text()}`);
  return await res.text();
}


async function transcribeGoogle(apiKey: string, base64: string, mimeType: string, model: string): Promise<string> {
  const j = await fetchGeminiWithRetry(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`,
    {
      contents: [{
        role: "user",
        parts: [
          { text: `${TRANSCRIBE_SYSTEM}\n\nТранскрибируй этот звонок дословно.` },
          { inline_data: { mime_type: mimeType, data: base64 } },
        ],
      }],
    },
  );
  return j.candidates?.[0]?.content?.parts?.map((p: any) => p.text).filter(Boolean).join("\n") ?? "";
}

// ---------- Analysis ----------
async function analyzeLovable(apiKey: string, systemPrompt: string, transcript: string, model: string) {
  const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: `google/${model}`,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `Транскрипт звонка:\n\n${transcript}` },
      ],
      tools: [ANALYSIS_TOOL],
      tool_choice: { type: "function", function: { name: "submit_call_analysis" } },
    }),
  });
  if (!res.ok) throw new Error(`Lovable AI ${res.status}: ${await res.text()}`);
  const j = await res.json();
  const tc = j.choices?.[0]?.message?.tool_calls?.[0];
  if (!tc) throw new Error("AI did not return structured analysis");
  return JSON.parse(tc.function.arguments);
}

async function analyzeOpenAI(apiKey: string, systemPrompt: string, transcript: string, model: string) {
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `Транскрипт звонка:\n\n${transcript}` },
      ],
      tools: [ANALYSIS_TOOL],
      tool_choice: { type: "function", function: { name: "submit_call_analysis" } },
    }),
  });
  if (!res.ok) throw new Error(`OpenAI ${res.status}: ${await res.text()}`);
  const j = await res.json();
  const tc = j.choices?.[0]?.message?.tool_calls?.[0];
  if (!tc) throw new Error("OpenAI did not return structured analysis");
  return JSON.parse(tc.function.arguments);
}


function stripAdditionalProps(obj: any): any {
  if (Array.isArray(obj)) return obj.map(stripAdditionalProps);
  if (obj && typeof obj === "object") {
    const out: any = {};
    for (const [k, v] of Object.entries(obj)) {
      if (k === "additionalProperties") continue;
      out[k] = stripAdditionalProps(v);
    }
    return out;
  }
  return obj;
}

async function analyzeGoogle(apiKey: string, systemPrompt: string, transcript: string, model: string) {
  const j = await fetchGeminiWithRetry(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`,
    {
      systemInstruction: { parts: [{ text: systemPrompt }] },
      contents: [{ role: "user", parts: [{ text: `Транскрипт звонка:\n\n${transcript}` }] }],
      tools: [{ functionDeclarations: [stripAdditionalProps(ANALYSIS_TOOL.function)] }],
      toolConfig: { functionCallingConfig: { mode: "ANY", allowedFunctionNames: ["submit_call_analysis"] } },
    },
  );
  const fc = j.candidates?.[0]?.content?.parts?.find((p: any) => p.functionCall)?.functionCall;
  if (!fc?.args) throw new Error("Google did not return structured analysis");
  return fc.args;
}

// OpenAI-compatible chat completion with tool calling (DeepSeek, Qwen via DashScope-compat, also generic).
async function analyzeOpenAICompat(
  apiKey: string,
  baseUrl: string,
  model: string,
  systemPrompt: string,
  transcript: string,
  providerLabel: string,
) {
  const res = await fetch(`${baseUrl}/chat/completions`, {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `Транскрипт звонка:\n\n${transcript}` },
      ],
      tools: [ANALYSIS_TOOL],
      tool_choice: { type: "function", function: { name: "submit_call_analysis" } },
    }),
  });
  if (!res.ok) throw new Error(`${providerLabel} ${res.status}: ${await res.text()}`);
  const j = await res.json();
  const tc = j.choices?.[0]?.message?.tool_calls?.[0];
  if (!tc) throw new Error(`${providerLabel} did not return structured analysis`);
  return JSON.parse(tc.function.arguments);
}

async function analyzeAnthropic(apiKey: string, systemPrompt: string, transcript: string, model: string) {
  const tool = {
    name: ANALYSIS_TOOL.function.name,
    description: ANALYSIS_TOOL.function.description,
    input_schema: stripAdditionalProps(ANALYSIS_TOOL.function.parameters),
  };
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model,
      max_tokens: 4096,
      system: systemPrompt,
      messages: [{ role: "user", content: `Транскрипт звонка:\n\n${transcript}` }],
      tools: [tool],
      tool_choice: { type: "tool", name: tool.name },
    }),
  });
  if (!res.ok) throw new Error(`Anthropic ${res.status}: ${await res.text()}`);
  const j = await res.json();
  const block = (j.content ?? []).find((b: any) => b.type === "tool_use");
  if (!block?.input) throw new Error("Anthropic did not return structured analysis");
  return block.input;
}


async function processCall(callId: string): Promise<void> {
  const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
  const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
  const admin = createClient(SUPABASE_URL, SERVICE_KEY);

  try {
    const { data: call, error: cerr } = await admin.from("calls").select("*").eq("id", callId).single();
    if (cerr || !call) throw new Error("Call not found");

    const { data: instruction } = await admin
      .from("instructions").select("*").eq("is_active", true)
      .order("updated_at", { ascending: false }).limit(1).maybeSingle();

    const { data: settings } = await admin.from("ai_settings").select("*").limit(1).maybeSingle();

    const transcriptionProvider: Provider = (settings?.transcription_provider ?? "lovable") as Provider;
    const analysisProvider: Provider = (settings?.analysis_provider ?? "lovable") as Provider;

    // Read provider keys from Vault using their secret ids (service role only)
    async function readVaultSecret(secretId: string | null | undefined): Promise<string | null> {
      if (!secretId) return null;
      const { data, error } = await admin
        .schema("vault" as any)
        .from("decrypted_secrets")
        .select("decrypted_secret")
        .eq("id", secretId)
        .maybeSingle();
      if (error) {
        console.error("vault read error", error);
        return null;
      }
      return (data as any)?.decrypted_secret ?? null;
    }
    const openaiKey: string | null = await readVaultSecret((settings as any)?.openai_secret_id);
    const googleKey: string | null = await readVaultSecret((settings as any)?.google_secret_id);
    const deepseekKey: string | null = await readVaultSecret((settings as any)?.deepseek_secret_id);
    const anthropicKey: string | null = await readVaultSecret((settings as any)?.anthropic_secret_id);
    const qwenKey: string | null = await readVaultSecret((settings as any)?.qwen_secret_id);
    // For Gemini-based providers, normalize aliases; for others use stored model verbatim.
    const rawTranscriptionModel = (settings?.transcription_model ?? "").trim();
    const rawAnalysisModel = (settings?.analysis_model ?? "").trim();
    const transcriptionModel = (transcriptionProvider === "lovable" || transcriptionProvider === "google")
      ? normalizeGeminiModel(rawTranscriptionModel, "gemini-2.5-flash")
      : (rawTranscriptionModel || (transcriptionProvider === "openai" ? "whisper-1" : "gemini-2.5-flash"));
    const analysisModelDefaults: Record<Provider, string> = {
      lovable: "gemini-2.5-flash",
      google: "gemini-2.5-flash",
      openai: "gpt-4o-mini",
      deepseek: "deepseek-chat",
      anthropic: "claude-3-5-sonnet-latest",
      qwen: "qwen-plus",
    };
    const analysisModel = (analysisProvider === "lovable" || analysisProvider === "google")
      ? normalizeGeminiModel(rawAnalysisModel, "gemini-2.5-flash")
      : (rawAnalysisModel || analysisModelDefaults[analysisProvider]);


    if (transcriptionProvider === "openai" && !openaiKey) throw new Error("OpenAI API ключ не задан");
    if (transcriptionProvider === "google" && !googleKey) throw new Error("Google API ключ не задан");
    if (["deepseek", "anthropic", "qwen"].includes(transcriptionProvider)) {
      throw new Error(`Провайдер "${transcriptionProvider}" не поддерживает транскрипцию аудио. Выберите Lovable, OpenAI или Google.`);
    }
    if (analysisProvider === "openai" && !openaiKey) throw new Error("OpenAI API ключ не задан");
    if (analysisProvider === "google" && !googleKey) throw new Error("Google API ключ не задан");
    if (analysisProvider === "deepseek" && !deepseekKey) throw new Error("DeepSeek API ключ не задан");
    if (analysisProvider === "anthropic" && !anthropicKey) throw new Error("Anthropic (Claude) API ключ не задан");
    if (analysisProvider === "qwen" && !qwenKey) throw new Error("Qwen API ключ не задан");
    if ((transcriptionProvider === "lovable" || analysisProvider === "lovable") && !LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY not configured");
    }

    let transcript = typeof call.transcript === "string" ? call.transcript.trim() : "";

    if (transcript) {
      await admin.from("calls").update({ status: "analyzing", instruction_id: instruction?.id ?? null, error_message: null }).eq("id", callId);
    } else {
      await admin.from("calls").update({ status: "transcribing", instruction_id: instruction?.id ?? null, error_message: null }).eq("id", callId);

      const { data: fileData, error: derr } = await admin.storage.from("call-audio").download(call.storage_path);
      if (derr || !fileData) throw new Error("Failed to download audio: " + derr?.message);

      const mimeType = guessMime(call.file_name);

      if (transcriptionProvider === "openai") {
        transcript = await transcribeOpenAI(openaiKey!, fileData, call.file_name, transcriptionModel);
      } else if (transcriptionProvider === "google") {
        const base64 = await blobToBase64(fileData);
        transcript = await transcribeGoogle(googleKey!, base64, mimeType, transcriptionModel);
      } else {
        const base64 = await blobToBase64(fileData);
        transcript = await transcribeLovable(LOVABLE_API_KEY!, `data:${mimeType};base64,${base64}`, transcriptionModel);
      }
      if (!transcript.trim()) throw new Error("Пустой транскрипт от модели");
    }

    await admin.from("calls").update({ status: "analyzing", transcript }).eq("id", callId);

    const scaleRule = `\n\nВАЖНО: Все оценки используют шкалу строго от 0 до 10 (допускаются дробные значения, например 7.5). НЕ используй шкалу 0-100 и НЕ выставляй значения больше 10. overall_score — число от 0 до 10. Каждый criteria[].score — число от 0 до 10.`;
    const systemPrompt = (instruction?.content
      ? `Ты — эксперт по контролю качества телефонных разговоров отдела продаж. Используй следующую инструкцию для оценки:\n\n${instruction.content}\n\nПроанализируй транскрипт звонка и верни структурированную оценку.`
      : `Ты — эксперт по контролю качества телефонных разговоров. Проанализируй транскрипт звонка отдела продаж и оцени его по основным критериям: приветствие, выявление потребностей, презентация, работа с возражениями, закрытие.`) + scaleRule;

    let analysis: unknown;
    if (analysisProvider === "openai") {
      analysis = await analyzeOpenAI(openaiKey!, systemPrompt, transcript, analysisModel);
    } else if (analysisProvider === "google") {
      analysis = await analyzeGoogle(googleKey!, systemPrompt, transcript, analysisModel);
    } else if (analysisProvider === "deepseek") {
      analysis = await analyzeOpenAICompat(deepseekKey!, "https://api.deepseek.com/v1", analysisModel, systemPrompt, transcript, "DeepSeek");
    } else if (analysisProvider === "anthropic") {
      analysis = await analyzeAnthropic(anthropicKey!, systemPrompt, transcript, analysisModel);
    } else if (analysisProvider === "qwen") {
      analysis = await analyzeOpenAICompat(qwenKey!, "https://dashscope-intl.aliyuncs.com/compatible-mode/v1", analysisModel, systemPrompt, transcript, "Qwen");
    } else {

      analysis = await analyzeLovable(LOVABLE_API_KEY!, systemPrompt, transcript, analysisModel);
    }

    await admin.from("calls").update({ status: "done", analysis, error_message: null }).eq("id", callId);
  } catch (e) {
    console.error("process-call background error:", e);
    const msg = userFriendlyError(e instanceof Error ? e.message : "Unknown error");
    await admin.from("calls").update({ status: "error", error_message: msg }).eq("id", callId);
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { callId } = await req.json();
    if (!callId) throw new Error("callId is required");

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) throw new Error("Missing auth");
    const userClient = createClient(
      SUPABASE_URL,
      Deno.env.get("SUPABASE_PUBLISHABLE_KEY") ?? Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );
    const { data: userData, error: uerr } = await userClient.auth.getUser();
    if (uerr || !userData.user) throw new Error("Unauthorized");

    // Authorization: ensure the caller owns this call (or is admin).
    // RLS on `calls` restricts SELECT to uploaded_by = auth.uid() OR admin,
    // so this query returns no row if the user isn't authorized.
    const { data: ownedCall, error: ownErr } = await userClient
      .from("calls")
      .select("id")
      .eq("id", callId)
      .maybeSingle();
    if (ownErr) throw new Error("Authorization check failed");
    if (!ownedCall) {
      return new Response(JSON.stringify({ error: "Not found or not authorized" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Run heavy work in background so client disconnects don't abort it.
    // @ts-ignore EdgeRuntime is provided by Supabase
    EdgeRuntime.waitUntil(processCall(callId));

    return new Response(JSON.stringify({ accepted: true, callId }), {
      status: 202,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("process-call error:", e);
    const msg = e instanceof Error ? e.message : "Unknown error";
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
