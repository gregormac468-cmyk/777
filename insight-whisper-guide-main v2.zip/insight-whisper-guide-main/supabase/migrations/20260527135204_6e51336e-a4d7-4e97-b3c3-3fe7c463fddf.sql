
DROP POLICY IF EXISTS "calls own read" ON public.calls;
CREATE POLICY "calls own read" ON public.calls
FOR SELECT TO authenticated
USING (
  uploaded_by = auth.uid()
  AND (
    has_role(auth.uid(), 'admin'::app_role)
    OR has_role(auth.uid(), 'head'::app_role)
    OR has_role(auth.uid(), 'manager'::app_role)
  )
);

DROP POLICY IF EXISTS "calls own update" ON public.calls;
CREATE POLICY "calls own update" ON public.calls
FOR UPDATE TO authenticated
USING (
  (uploaded_by = auth.uid() AND (
    has_role(auth.uid(), 'admin'::app_role)
    OR has_role(auth.uid(), 'head'::app_role)
    OR has_role(auth.uid(), 'manager'::app_role)
  ))
  OR has_role(auth.uid(), 'admin'::app_role)
)
WITH CHECK (
  (uploaded_by = auth.uid() AND (
    has_role(auth.uid(), 'admin'::app_role)
    OR has_role(auth.uid(), 'head'::app_role)
    OR has_role(auth.uid(), 'manager'::app_role)
  ))
  OR has_role(auth.uid(), 'admin'::app_role)
);
