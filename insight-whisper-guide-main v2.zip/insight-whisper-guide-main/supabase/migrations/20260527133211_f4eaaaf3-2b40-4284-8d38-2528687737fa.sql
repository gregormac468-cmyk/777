DROP POLICY IF EXISTS "activity_logs self insert" ON public.activity_logs;
CREATE POLICY "activity_logs roled self insert"
ON public.activity_logs
FOR INSERT
TO authenticated
WITH CHECK (
  user_id = auth.uid()
  AND (
    public.has_role(auth.uid(), 'admin'::public.app_role)
    OR public.has_role(auth.uid(), 'head'::public.app_role)
    OR public.has_role(auth.uid(), 'manager'::public.app_role)
  )
);