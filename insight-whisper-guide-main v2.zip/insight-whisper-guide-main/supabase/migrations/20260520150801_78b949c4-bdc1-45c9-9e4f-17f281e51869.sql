-- Ensure Supabase Vault is available
CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;

-- Add new columns: secret references + display masks
ALTER TABLE public.ai_settings
  ADD COLUMN IF NOT EXISTS openai_secret_id uuid,
  ADD COLUMN IF NOT EXISTS google_secret_id uuid,
  ADD COLUMN IF NOT EXISTS openai_key_mask text,
  ADD COLUMN IF NOT EXISTS google_key_mask text;

-- Migrate any existing plaintext keys into Vault
DO $$
DECLARE
  s record;
  sid uuid;
BEGIN
  FOR s IN SELECT id, openai_api_key, google_api_key FROM public.ai_settings LOOP
    IF s.openai_api_key IS NOT NULL AND length(s.openai_api_key) > 0 THEN
      sid := vault.create_secret(s.openai_api_key, 'ai_settings_openai_' || s.id::text);
      UPDATE public.ai_settings
        SET openai_secret_id = sid,
            openai_key_mask = CASE WHEN length(s.openai_api_key) <= 8
                                   THEN '••••'
                                   ELSE left(s.openai_api_key,4) || '••••' || right(s.openai_api_key,4) END
        WHERE id = s.id;
    END IF;
    IF s.google_api_key IS NOT NULL AND length(s.google_api_key) > 0 THEN
      sid := vault.create_secret(s.google_api_key, 'ai_settings_google_' || s.id::text);
      UPDATE public.ai_settings
        SET google_secret_id = sid,
            google_key_mask = CASE WHEN length(s.google_api_key) <= 8
                                   THEN '••••'
                                   ELSE left(s.google_api_key,4) || '••••' || right(s.google_api_key,4) END
        WHERE id = s.id;
    END IF;
  END LOOP;
END $$;

-- Remove plaintext columns
ALTER TABLE public.ai_settings DROP COLUMN IF EXISTS openai_api_key;
ALTER TABLE public.ai_settings DROP COLUMN IF EXISTS google_api_key;

-- Admin-only RPC to set/clear a provider key (key never leaves server)
CREATE OR REPLACE FUNCTION public.set_ai_provider_key(_provider text, _key text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_settings_id uuid;
  v_old_id uuid;
  v_new_id uuid;
  v_mask text;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RAISE EXCEPTION 'forbidden';
  END IF;
  IF _provider NOT IN ('openai','google') THEN
    RAISE EXCEPTION 'invalid provider';
  END IF;

  SELECT id INTO v_settings_id FROM public.ai_settings LIMIT 1;
  IF v_settings_id IS NULL THEN
    RAISE EXCEPTION 'ai_settings row missing';
  END IF;

  IF _key IS NULL OR length(btrim(_key)) = 0 THEN
    IF _provider = 'openai' THEN
      SELECT openai_secret_id INTO v_old_id FROM public.ai_settings WHERE id = v_settings_id;
      UPDATE public.ai_settings
         SET openai_secret_id = NULL, openai_key_mask = NULL, updated_by = auth.uid()
       WHERE id = v_settings_id;
    ELSE
      SELECT google_secret_id INTO v_old_id FROM public.ai_settings WHERE id = v_settings_id;
      UPDATE public.ai_settings
         SET google_secret_id = NULL, google_key_mask = NULL, updated_by = auth.uid()
       WHERE id = v_settings_id;
    END IF;
    IF v_old_id IS NOT NULL THEN
      DELETE FROM vault.secrets WHERE id = v_old_id;
    END IF;
    RETURN;
  END IF;

  v_mask := CASE WHEN length(_key) <= 8
                 THEN '••••'
                 ELSE left(_key,4) || '••••' || right(_key,4) END;

  v_new_id := vault.create_secret(_key, _provider || '_api_key_' || gen_random_uuid()::text);

  IF _provider = 'openai' THEN
    SELECT openai_secret_id INTO v_old_id FROM public.ai_settings WHERE id = v_settings_id;
    UPDATE public.ai_settings
       SET openai_secret_id = v_new_id, openai_key_mask = v_mask, updated_by = auth.uid()
     WHERE id = v_settings_id;
  ELSE
    SELECT google_secret_id INTO v_old_id FROM public.ai_settings WHERE id = v_settings_id;
    UPDATE public.ai_settings
       SET google_secret_id = v_new_id, google_key_mask = v_mask, updated_by = auth.uid()
     WHERE id = v_settings_id;
  END IF;

  IF v_old_id IS NOT NULL THEN
    DELETE FROM vault.secrets WHERE id = v_old_id;
  END IF;
END;
$$;

REVOKE ALL ON FUNCTION public.set_ai_provider_key(text, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.set_ai_provider_key(text, text) TO authenticated;