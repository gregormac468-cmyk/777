UPDATE public.ai_settings SET transcription_model = 'gemini-1.5-flash-latest' WHERE transcription_model = 'gemini-1.5-flash';
UPDATE public.ai_settings SET analysis_model = 'gemini-1.5-pro-latest' WHERE analysis_model = 'gemini-1.5-pro';
UPDATE public.calls SET status = 'pending', error_message = NULL WHERE status IN ('transcribing','analyzing');