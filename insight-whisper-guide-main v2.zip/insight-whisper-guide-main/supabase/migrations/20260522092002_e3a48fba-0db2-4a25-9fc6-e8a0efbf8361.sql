
-- Table for per-user daily upload limits
CREATE TABLE public.user_limits (
  user_id uuid PRIMARY KEY,
  daily_limit integer,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid
);

ALTER TABLE public.user_limits ENABLE ROW LEVEL SECURITY;

CREATE POLICY "user_limits admin all" ON public.user_limits
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'::public.app_role))
  WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "user_limits self read" ON public.user_limits
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

-- Function: returns today's usage and configured limit for a user
CREATE OR REPLACE FUNCTION public.get_user_daily_usage(_user_id uuid)
RETURNS TABLE(used integer, daily_limit integer)
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF _user_id <> auth.uid() AND NOT public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RAISE EXCEPTION 'forbidden';
  END IF;

  RETURN QUERY
  SELECT
    (SELECT COUNT(*)::int FROM public.calls
      WHERE uploaded_by = _user_id
        AND created_at >= date_trunc('day', now()))::int AS used,
    (SELECT ul.daily_limit FROM public.user_limits ul WHERE ul.user_id = _user_id) AS daily_limit;
END;
$$;

-- Trigger: enforce daily limit on calls insert
CREATE OR REPLACE FUNCTION public.enforce_daily_call_limit()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_limit integer;
  v_used integer;
BEGIN
  SELECT ul.daily_limit INTO v_limit
  FROM public.user_limits ul
  WHERE ul.user_id = NEW.uploaded_by;

  IF v_limit IS NULL THEN
    RETURN NEW;
  END IF;

  SELECT COUNT(*)::int INTO v_used
  FROM public.calls
  WHERE uploaded_by = NEW.uploaded_by
    AND created_at >= date_trunc('day', now());

  IF v_used >= v_limit THEN
    RAISE EXCEPTION 'Достигнут суточный лимит: %/% звонков. Обратитесь к администратору.', v_used, v_limit
      USING ERRCODE = 'P0001';
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER calls_daily_limit_check
  BEFORE INSERT ON public.calls
  FOR EACH ROW
  EXECUTE FUNCTION public.enforce_daily_call_limit();
