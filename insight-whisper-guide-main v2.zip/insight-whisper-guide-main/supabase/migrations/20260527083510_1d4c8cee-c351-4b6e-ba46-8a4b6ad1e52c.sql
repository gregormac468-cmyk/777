
DROP POLICY IF EXISTS "instructions admin write" ON public.instructions;
CREATE POLICY "instructions admin or head write"
ON public.instructions
FOR ALL
TO authenticated
USING (public.has_role(auth.uid(), 'admin'::app_role) OR public.has_role(auth.uid(), 'head'::app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::app_role) OR public.has_role(auth.uid(), 'head'::app_role));
