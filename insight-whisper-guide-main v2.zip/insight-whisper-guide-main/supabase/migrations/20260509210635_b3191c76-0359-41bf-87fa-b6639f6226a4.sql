CREATE TABLE public.ai_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  singleton boolean NOT NULL DEFAULT true UNIQUE,
  transcription_provider text NOT NULL DEFAULT 'lovable',
  analysis_provider text NOT NULL DEFAULT 'lovable',
  openai_api_key text,
  google_api_key text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid,
  CONSTRAINT transcription_provider_valid CHECK (transcription_provider IN ('lovable','openai','google')),
  CONSTRAINT analysis_provider_valid CHECK (analysis_provider IN ('lovable','openai','google'))
);

ALTER TABLE public.ai_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ai_settings admin read" ON public.ai_settings
  FOR SELECT TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "ai_settings admin write" ON public.ai_settings
  FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER ai_settings_updated_at
  BEFORE UPDATE ON public.ai_settings
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

INSERT INTO public.ai_settings (singleton) VALUES (true);