
REVOKE EXECUTE ON FUNCTION public.calls_restrict_user_updates() FROM PUBLIC, anon, authenticated;
