
-- Trigger to block non-admin users from modifying protected columns on calls
CREATE OR REPLACE FUNCTION public.calls_restrict_user_updates()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- service_role bypasses (used by edge functions via admin client)
  IF current_setting('request.jwt.claim.role', true) = 'service_role' THEN
    RETURN NEW;
  END IF;

  -- admins can update any column
  IF auth.uid() IS NOT NULL AND public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RETURN NEW;
  END IF;

  -- For everyone else, allow changes only to status and error_message
  IF NEW.analysis IS DISTINCT FROM OLD.analysis
     OR NEW.transcript IS DISTINCT FROM OLD.transcript
     OR NEW.file_name IS DISTINCT FROM OLD.file_name
     OR NEW.storage_path IS DISTINCT FROM OLD.storage_path
     OR NEW.duration_seconds IS DISTINCT FROM OLD.duration_seconds
     OR NEW.instruction_id IS DISTINCT FROM OLD.instruction_id
     OR NEW.manager_name IS DISTINCT FROM OLD.manager_name
     OR NEW.uploaded_by IS DISTINCT FROM OLD.uploaded_by
     OR NEW.created_at IS DISTINCT FROM OLD.created_at
     OR NEW.id IS DISTINCT FROM OLD.id
  THEN
    RAISE EXCEPTION 'Only status and error_message may be updated by users'
      USING ERRCODE = '42501';
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS calls_restrict_user_updates_trg ON public.calls;
CREATE TRIGGER calls_restrict_user_updates_trg
BEFORE UPDATE ON public.calls
FOR EACH ROW
EXECUTE FUNCTION public.calls_restrict_user_updates();

-- Add explicit UPDATE policy on call-audio storage bucket mirroring INSERT
DROP POLICY IF EXISTS "call-audio owner update" ON storage.objects;
CREATE POLICY "call-audio owner update"
ON storage.objects
FOR UPDATE
TO authenticated
USING (bucket_id = 'call-audio' AND owner = auth.uid())
WITH CHECK (bucket_id = 'call-audio' AND owner = auth.uid());
