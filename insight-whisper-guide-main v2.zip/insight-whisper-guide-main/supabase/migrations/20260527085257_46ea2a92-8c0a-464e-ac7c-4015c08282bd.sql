-- Attach trigger to enforce that non-admin users cannot modify analysis/transcript/etc on calls
DROP TRIGGER IF EXISTS calls_restrict_user_updates_trg ON public.calls;
CREATE TRIGGER calls_restrict_user_updates_trg
BEFORE UPDATE ON public.calls
FOR EACH ROW
EXECUTE FUNCTION public.calls_restrict_user_updates();