
-- Tighten calls insert: require an assigned role
DROP POLICY IF EXISTS "calls own insert" ON public.calls;
CREATE POLICY "calls own insert"
ON public.calls
FOR INSERT
TO authenticated
WITH CHECK (
  uploaded_by = auth.uid()
  AND (
    public.has_role(auth.uid(), 'admin'::public.app_role)
    OR public.has_role(auth.uid(), 'manager'::public.app_role)
    OR public.has_role(auth.uid(), 'head'::public.app_role)
  )
);

-- Tighten audio storage insert: require an assigned role
DROP POLICY IF EXISTS "audio own insert" ON storage.objects;
CREATE POLICY "audio own insert"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'call-audio'
  AND auth.uid()::text = (storage.foldername(name))[1]
  AND (
    public.has_role(auth.uid(), 'admin'::public.app_role)
    OR public.has_role(auth.uid(), 'manager'::public.app_role)
    OR public.has_role(auth.uid(), 'head'::public.app_role)
  )
);
