DROP POLICY IF EXISTS "managers insert" ON public.managers;
CREATE POLICY "managers admin or head insert"
ON public.managers
FOR INSERT
TO authenticated
WITH CHECK (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'head'::app_role));