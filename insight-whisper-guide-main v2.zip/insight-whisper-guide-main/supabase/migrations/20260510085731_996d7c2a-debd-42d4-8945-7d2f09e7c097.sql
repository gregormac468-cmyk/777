ALTER TABLE public.ai_settings
  ADD COLUMN IF NOT EXISTS transcription_model text NOT NULL DEFAULT 'gemini-2.5-flash',
  ADD COLUMN IF NOT EXISTS analysis_model text NOT NULL DEFAULT 'gemini-2.5-flash';