
-- Roles enum
CREATE TYPE public.app_role AS ENUM ('admin', 'manager');

-- Profiles
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT,
  full_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- User roles
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- has_role function
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

-- Instructions
CREATE TABLE public.instructions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  content TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT false,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.instructions ENABLE ROW LEVEL SECURITY;

-- Calls
CREATE TYPE public.call_status AS ENUM ('pending','transcribing','analyzing','done','error');

CREATE TABLE public.calls (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  uploaded_by UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  manager_name TEXT,
  file_name TEXT NOT NULL,
  storage_path TEXT NOT NULL,
  duration_seconds INTEGER,
  status public.call_status NOT NULL DEFAULT 'pending',
  error_message TEXT,
  transcript TEXT,
  analysis JSONB,
  instruction_id UUID REFERENCES public.instructions(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.calls ENABLE ROW LEVEL SECURITY;

-- updated_at trigger
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;
CREATE TRIGGER calls_updated_at BEFORE UPDATE ON public.calls
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER instructions_updated_at BEFORE UPDATE ON public.instructions
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Auto-create profile + first user is admin
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  user_count INTEGER;
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', ''));

  SELECT COUNT(*) INTO user_count FROM auth.users;
  IF user_count = 1 THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'admin');
  ELSE
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'manager');
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- RLS policies: profiles
CREATE POLICY "profiles self read" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = id);
CREATE POLICY "profiles admin read" ON public.profiles FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE POLICY "profiles self update" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id);

-- RLS: user_roles
CREATE POLICY "roles self read" ON public.user_roles FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "roles admin all" ON public.user_roles FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- RLS: instructions (all authenticated read; admin writes)
CREATE POLICY "instructions read" ON public.instructions FOR SELECT TO authenticated USING (true);
CREATE POLICY "instructions admin write" ON public.instructions FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- RLS: calls
CREATE POLICY "calls own read" ON public.calls FOR SELECT TO authenticated USING (uploaded_by = auth.uid());
CREATE POLICY "calls admin read" ON public.calls FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE POLICY "calls own insert" ON public.calls FOR INSERT TO authenticated WITH CHECK (uploaded_by = auth.uid());
CREATE POLICY "calls own update" ON public.calls FOR UPDATE TO authenticated USING (uploaded_by = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "calls admin delete" ON public.calls FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'));

-- Storage bucket for audio
INSERT INTO storage.buckets (id, name, public) VALUES ('call-audio','call-audio', false);

CREATE POLICY "audio own read" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'call-audio' AND (auth.uid()::text = (storage.foldername(name))[1] OR public.has_role(auth.uid(),'admin')));
CREATE POLICY "audio own insert" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'call-audio' AND auth.uid()::text = (storage.foldername(name))[1]);
CREATE POLICY "audio own delete" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'call-audio' AND (auth.uid()::text = (storage.foldername(name))[1] OR public.has_role(auth.uid(),'admin')));
