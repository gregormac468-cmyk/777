
ALTER TABLE public.ai_settings
  ADD COLUMN IF NOT EXISTS deepseek_secret_id uuid,
  ADD COLUMN IF NOT EXISTS deepseek_key_mask text,
  ADD COLUMN IF NOT EXISTS anthropic_secret_id uuid,
  ADD COLUMN IF NOT EXISTS anthropic_key_mask text,
  ADD COLUMN IF NOT EXISTS qwen_secret_id uuid,
  ADD COLUMN IF NOT EXISTS qwen_key_mask text;

ALTER TABLE public.ai_settings DROP CONSTRAINT IF EXISTS transcription_provider_valid;
ALTER TABLE public.ai_settings DROP CONSTRAINT IF EXISTS analysis_provider_valid;
ALTER TABLE public.ai_settings
  ADD CONSTRAINT transcription_provider_valid
    CHECK (transcription_provider = ANY (ARRAY['lovable','openai','google','deepseek','anthropic','qwen'])),
  ADD CONSTRAINT analysis_provider_valid
    CHECK (analysis_provider = ANY (ARRAY['lovable','openai','google','deepseek','anthropic','qwen']));

CREATE OR REPLACE FUNCTION public.set_ai_provider_key(_provider text, _key text)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_settings_id uuid;
  v_old_id uuid;
  v_new_id uuid;
  v_mask text;
  v_secret_col text;
  v_mask_col text;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RAISE EXCEPTION 'forbidden';
  END IF;
  IF _provider NOT IN ('openai','google','deepseek','anthropic','qwen') THEN
    RAISE EXCEPTION 'invalid provider';
  END IF;

  v_secret_col := _provider || '_secret_id';
  v_mask_col   := _provider || '_key_mask';
  IF _provider = 'anthropic' THEN
    v_secret_col := 'anthropic_secret_id';
    v_mask_col   := 'anthropic_key_mask';
  END IF;

  SELECT id INTO v_settings_id FROM public.ai_settings LIMIT 1;
  IF v_settings_id IS NULL THEN
    RAISE EXCEPTION 'ai_settings row missing';
  END IF;

  EXECUTE format('SELECT %I FROM public.ai_settings WHERE id = $1', v_secret_col)
    INTO v_old_id USING v_settings_id;

  IF _key IS NULL OR length(btrim(_key)) = 0 THEN
    EXECUTE format(
      'UPDATE public.ai_settings SET %I = NULL, %I = NULL, updated_by = $1 WHERE id = $2',
      v_secret_col, v_mask_col
    ) USING auth.uid(), v_settings_id;
    IF v_old_id IS NOT NULL THEN
      DELETE FROM vault.secrets WHERE id = v_old_id;
    END IF;
    RETURN;
  END IF;

  v_mask := CASE WHEN length(_key) <= 8
                 THEN '••••'
                 ELSE left(_key,4) || '••••' || right(_key,4) END;

  v_new_id := vault.create_secret(_key, _provider || '_api_key_' || gen_random_uuid()::text);

  EXECUTE format(
    'UPDATE public.ai_settings SET %I = $1, %I = $2, updated_by = $3 WHERE id = $4',
    v_secret_col, v_mask_col
  ) USING v_new_id, v_mask, auth.uid(), v_settings_id;

  IF v_old_id IS NOT NULL THEN
    DELETE FROM vault.secrets WHERE id = v_old_id;
  END IF;
END;
$function$;
