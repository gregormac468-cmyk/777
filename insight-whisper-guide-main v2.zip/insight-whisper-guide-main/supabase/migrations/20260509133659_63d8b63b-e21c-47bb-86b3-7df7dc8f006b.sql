
CREATE TABLE public.managers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  position text,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.managers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "managers read" ON public.managers
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "managers insert" ON public.managers
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "managers admin delete" ON public.managers
  FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "managers admin update" ON public.managers
  FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
