
-- 1. ai_settings: replace permissive ALL policy with explicit per-command policies (admin only)
DROP POLICY IF EXISTS "ai_settings admin write" ON public.ai_settings;
DROP POLICY IF EXISTS "ai_settings admin read" ON public.ai_settings;

CREATE POLICY "ai_settings admin select" ON public.ai_settings
  FOR SELECT TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "ai_settings admin insert" ON public.ai_settings
  FOR INSERT TO authenticated
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "ai_settings admin update" ON public.ai_settings
  FOR UPDATE TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "ai_settings admin delete" ON public.ai_settings
  FOR DELETE TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role));

-- 2. user_roles: add explicit RESTRICTIVE policy ensuring only admins can write
CREATE POLICY "user_roles block non-admin insert" ON public.user_roles
  AS RESTRICTIVE FOR INSERT TO authenticated
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "user_roles block non-admin update" ON public.user_roles
  AS RESTRICTIVE FOR UPDATE TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "user_roles block non-admin delete" ON public.user_roles
  AS RESTRICTIVE FOR DELETE TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role));

-- 3. has_role: revoke EXECUTE from anon/authenticated; still usable inside RLS policies (SECURITY DEFINER, owner-evaluated)
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, app_role) FROM PUBLIC, anon, authenticated;
