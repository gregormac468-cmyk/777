
-- 1) Secure reprocess RPC
CREATE OR REPLACE FUNCTION public.reset_call_for_reprocess(_call_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_owner uuid;
BEGIN
  SELECT uploaded_by INTO v_owner FROM public.calls WHERE id = _call_id;
  IF v_owner IS NULL THEN
    RAISE EXCEPTION 'call not found';
  END IF;
  IF v_owner <> auth.uid() AND NOT public.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RAISE EXCEPTION 'forbidden';
  END IF;
  UPDATE public.calls
     SET status = 'pending'::call_status,
         error_message = NULL,
         analysis = NULL,
         updated_at = now()
   WHERE id = _call_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.reset_call_for_reprocess(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.reset_call_for_reprocess(uuid) TO authenticated;

-- Batch variant
CREATE OR REPLACE FUNCTION public.reset_calls_for_reprocess(_call_ids uuid[])
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_id uuid;
BEGIN
  IF _call_ids IS NULL THEN RETURN; END IF;
  FOREACH v_id IN ARRAY _call_ids LOOP
    PERFORM public.reset_call_for_reprocess(v_id);
  END LOOP;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.reset_calls_for_reprocess(uuid[]) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.reset_calls_for_reprocess(uuid[]) TO authenticated;

-- 2) Restrict column-level UPDATE on calls for authenticated users.
-- Only status + error_message can be changed via direct UPDATE; analysis/transcript
-- can only be reset via the SECURITY DEFINER RPC above or by the service role
-- (edge function) which bypasses these grants.
REVOKE UPDATE ON public.calls FROM authenticated;
GRANT UPDATE (status, error_message) ON public.calls TO authenticated;

-- 3) Enforce file size + mime allow-list on call-audio bucket.
UPDATE storage.buckets
   SET file_size_limit = 26214400,
       allowed_mime_types = ARRAY[
         'audio/mpeg','audio/mp3','audio/wav','audio/x-wav',
         'audio/ogg','audio/oga','audio/mp4','audio/x-m4a',
         'audio/webm','audio/flac','audio/aac','audio/m4a'
       ]
 WHERE id = 'call-audio';
